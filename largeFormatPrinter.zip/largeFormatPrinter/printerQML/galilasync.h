#ifndef GALILASYNC_H
#define GALILASYNC_H

#include "qmutex.h"
#include <QThread>
#include <QObject>
#include <gclib.h>
#include <gclibo.h>

class GalilAsync : public QThread
{
    Q_OBJECT
public:
    explicit GalilAsync(QObject *parent = nullptr);
    void run();

private:
    QString name;

    char buf[G_SMALL_BUFFER];
    GCon g = 0;
    std::atomic<bool> myLoop = false;

public slots:
    void quit();
signals:
    void galilConnectStatus();

};

#endif // GALILASYNC_H
