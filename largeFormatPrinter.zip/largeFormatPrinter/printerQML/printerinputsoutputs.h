#ifndef PRINTERINPUTSOUTPUTS_H
#define PRINTERINPUTSOUTPUTS_H

#include <QObject>
#include <QDebug>
#include <QQuickView>
#include <QQuickItem>
#include <QObject>
#include <QSharedDataPointer>
#include <QTimer>
#include <QThread>
#include <QtSerialPort/QSerialPort>
#include <gclib.h>
#include <gclibo.h>

//#pragma pack(1)

struct PrinterOutputData
{
    unsigned long inData;
    unsigned long ouData;
};

class PrinterInputsOutputs:public QObject
{
    Q_OBJECT
public:
    explicit PrinterInputsOutputs();
    void myLogik();
    void myBlink();
    void mySerial();
    void myGalil();
    QTimer timerLogik;
    QTimer timerBlink;
    QTimer timerGalil;

signals:
    void sendPrinterInput(long dta);
    void setInputs(void);
    void setOutputs(void);
    int getGuiOutups(int *res);
    void setPump1(bool b);
    void setPump2(bool b);
    void setPump3(bool b);
    void setPump4(bool b);

public slots:
    void inputSetData(int tab, int pos, int b);
    void outputSetData(int tab, int pos, int b);
    void printerConfirm();
    void operatorConfirm();
    void headConfirm();
    bool getInputs(int tab, int pos);
    bool getOutput(int tab, int pos);
    void setAuto(bool b);
    QString testParam(QString s);

private:
    PrinterOutputData myData[4];
    QSerialPort qserialPort;
    bool isPump1;
    bool blink1;
    bool isPump2;
    bool blink2;
    bool isPump3;
    bool blink3;
    bool isPump4;
    bool blink4;
    bool isAuto = true;

    char buf[G_SMALL_BUFFER];
    GCon g = 0;
};

#endif // PRINTERINPUTSOUTPUTS_H
