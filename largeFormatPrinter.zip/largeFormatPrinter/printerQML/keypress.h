#ifndef KEYPRESS_H
#define KEYPRESS_H

#include <QObject>
#include <QKeyEvent>


class KeyPress : public QObject
{
    Q_OBJECT

public:
    KeyPress(QWidget *parent = 0);

signals:
    void keyPressEvent(QKeyEvent *event);

};

#endif // KEYPRESS_H


