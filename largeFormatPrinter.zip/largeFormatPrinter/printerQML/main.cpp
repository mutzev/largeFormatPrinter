#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QDebug>
#include <QThread>
#include <iostream>
#include <string>
#include <QQuickView>
#include <QQuickItem>
#include <QQmlContext>
#include <QQmlComponent>
#include "galilasync.h"
#include "printerinputsoutputs.h"

/*

  да пусна таск, който
  да спирам и пускам
  от ауто - менюала за изходите
  а входовете да си иамт таск дет да си ги чете
  непрекъснато
  хм, то през сериен порт май
  няма как да стане с два таска....
 */

/*
 4 байта на екран
 всиюки изходи и входове - 4 байта
 Принтер
 Входове - 8 бита
 Изходи - 7 бита
 Оператор
 Входове 19 бита
 Изходи 26 бита
 Хеад
 Входове 18 бита
 Изходи 15 бита
 Други
 авто
 конфирм принтер
 конфирм оператор
 конфирм хеад
*/




int main(int argc, char *argv[])

{
    /*
//#ifdef QT_NO_DEBUG_OUTPUT
//   qputenv("QT_LOGGING_RULES", "qml=false");
//#endif

#ifdef QT_NO_DEBUG
    QLoggingCategory::setFilterRules("*.debug=false\n"
                                     "*.info=false\n"
                                     "*.warning=false\n"
                                     "*.critical=false");
#endif
*/
    QGuiApplication app(argc, argv);
    QQmlApplicationEngine engine;
    QQmlContext *context = engine.rootContext();

    qmlRegisterType<GalilAsync>("GalilAsync", 1, 0, "GalilAsync");

    PrinterInputsOutputs printerIO;
    context->setContextProperty("printerIO", &printerIO);

    const QUrl url(QStringLiteral("qrc:/main.qml"));

    QObject::connect(&engine, &QQmlApplicationEngine::objectCreated,&app, [url](QObject *obj, const QUrl &objUrl) {
        if (!obj && url == objUrl)QCoreApplication::exit(-1);
    }, Qt::QueuedConnection);
    engine.load(url);

    //std::cout << "vie console" << std::endl;
    qDebug() << "vie debug";

    return app.exec();
}
