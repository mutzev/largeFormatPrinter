#include "galilasync.h"
#include "qqml.h"
#include <QDebug>
#include <QtCore>
#include <QMetaType>
#include <gclib.h>
#include <gclibo.h>

GalilAsync::GalilAsync(QObject *parent)
    : QThread{parent}
{
    qDebug() << "c++ galil async init.";
   // qmlRegisterType<GalilAsync>("GalilAsync", 1, 0, "GalilAsync");
}

void GalilAsync::quit()
{
    qDebug() << "c++ galil try async quit.";

    QMutex mutex;
    mutex.lock();
    myLoop = true;
    mutex.unlock();

    this->wait(5000);

    qDebug() << "c++ galil async now really quit." << g;

}

void GalilAsync::run()
{
    g = 0;
    bool showInfo = false;
    myLoop = false;
    while(!myLoop) {
        if(g!=0)
        {
            if(showInfo) {
                GInfo(g, buf, sizeof(buf));
                qDebug() << buf << '\n';
                showInfo = false;
            }
            qDebug() << "send to qml:" << (g!=0?true:false);
            emit galilConnectStatus();

        }
        else
        {
            qDebug() << "Try to open galil controller";
            qDebug() << "send to qml:" << (g!=0?true:false);
            emit galilConnectStatus();

            QMutex mutex;
            mutex.lock();
            GOpen("192.168.0.2 -d", &g);
            if(g!=0) showInfo = true;
            mutex.unlock();
        }



        msleep(100);
    }
    qDebug() << "galil loop exit";

}
