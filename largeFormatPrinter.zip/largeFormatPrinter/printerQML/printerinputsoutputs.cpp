#include "printerinputsoutputs.h"
#include <QQuickView>
#include <QQuickItem>
#include <QObject>
#include <QThread>
#include <gclib.h>
#include <gclibo.h>
//#include "galilasync.h"

#define logicTimeInterval 50
#define blinkTimeInterval 500
#define galilTimeInterval 1000


/*
 пакета е:
 @1Rffffffff$

 4 байта на екран
 всиюки изходи и входове - 4 байта
 Принтер
 Входове - 8 бита
 Изходи - 7 бита
 Оператор
 Входове 19 бита
 Изходи 26 бита
 Хеад
 Входове 18 бита
 Изходи 15 бита
 Други
 авто
 конфирм принтер
 конфирм оператор
 конфирм хеад
*/

QString PrinterInputsOutputs::testParam(QString s)
{
    qDebug() << "ala bala:" << s;
    return "ala bala";
}
void PrinterInputsOutputs::setAuto(bool b)
{
    isAuto = b;

    if(isAuto)
    {
        timerLogik.start(logicTimeInterval);
        timerBlink.start(blinkTimeInterval);
    }
    else
    {
        timerLogik.stop();
        timerBlink.stop();
    }

}

void PrinterInputsOutputs::myBlink()
{
    if(isAuto)
    {
        if(isPump1)
        {
            emit setPump1(blink1);
            blink1^=1;
        }
        else
        {
            emit setPump1(false);
        }

        if(isPump2)
        {
            emit setPump2(blink2);
            blink2^=1;
        }
        else
        {
            emit setPump2(false);
        }

        if(isPump3)
        {
            emit setPump3(blink3);
            blink3^=1;
        }
        else
        {
            emit setPump3(false);
        }

        if(isPump4)
        {
            emit setPump4(blink4);
            blink4^=1;
        }
        else
        {
            emit setPump4(false);
        }

    }
}

void PrinterInputsOutputs::myLogik()
{
    if(isAuto){
        if(getInputs(2, 0))
        {
            isPump1 = true;
        }

        if(getInputs(2, 1))
        {
            isPump1 = false;
        }

        if(getInputs(2, 2))
        {
            isPump2 = true;
        }

        if(getInputs(2, 3))
        {
            isPump2 = false;
        }

        if(getInputs(2, 4))
        {
            isPump3 = true;
        }

        if(getInputs(2, 5))
        {
            isPump3 = false;
        }

        if(getInputs(2, 6))
        {
            isPump4 = true;
        }

        if(getInputs(2, 7))
        {
            isPump4 = false;
        }

    }
};

void PrinterInputsOutputs::mySerial()
{
    int byteRead = qserialPort.bytesAvailable();
    QByteArray datas = qserialPort.readAll();
    qDebug() << "nByte read:" << byteRead << " data:" << datas;
}

void PrinterInputsOutputs::myGalil()
{
    if(g!=0)
    {
//        GInfo(g, buf, sizeof(buf));
//        qDebug() << buf << '\n';
    }
    else
    {
       // GOpen("192.168.0.2 -d", &g);
    }
}

PrinterInputsOutputs::PrinterInputsOutputs()
{
    qDebug() << "init printer task";
    memset(myData,0,sizeof(myData));

    //qRegisterMetaType< int >();
    //qRegisterMetaType< QDate >();
    //qRegisterMetaType<int>("int");
    //qmlRegisterType<GalilAsync>("GalilAsync", 1, 0, "GalilAsync");

    connect(&timerLogik, &QTimer::timeout, this, &PrinterInputsOutputs::myLogik);
    connect(&timerBlink, &QTimer::timeout, this, &PrinterInputsOutputs::myBlink);

    if(isAuto)
    {
        timerLogik.start(logicTimeInterval);
        timerBlink.start(blinkTimeInterval);
    }

  //  timerGalil.start(galilTimeInterval);
  //  connect(&timerGalil, &QTimer::timeout, this, &PrinterInputsOutputs::myGalil);

    qserialPort.setPortName("COM1");
    qserialPort.setBaudRate(QSerialPort::Baud57600,QSerialPort::AllDirections);
    qserialPort.setDataBits(QSerialPort::Data8);
    qserialPort.setStopBits(QSerialPort::OneStop);
    qserialPort.setParity(QSerialPort::NoParity);
    qserialPort.open(QIODevice::ReadWrite);
    qserialPort.setFlowControl(QSerialPort::NoFlowControl);

    connect(&qserialPort, &QSerialPort::readyRead, this, &PrinterInputsOutputs::mySerial);

    /*
    connect(&qserialPort, &QSerialPort::readyRead, [&]
    {
        int byteRead = qserialPort.bytesAvailable();
        QByteArray datas = qserialPort.readAll();
        qDebug() << "nByte read:" << byteRead << " data:" << datas;
    });
    */
}

void PrinterInputsOutputs::headConfirm()
{
    QString valueInHex= "@W3" + QString("%1").arg(myData[2].ouData , 8, 16,  QLatin1Char( '0' )) + "$\r\n";
    qDebug() << "Send to serial:[" << valueInHex.toUpper() << "]\r";

    QByteArray ba = valueInHex.toUpper().toLocal8Bit();
    const char *c_str2 = ba.data();
    int l = ba.length();

    qserialPort.write(c_str2,l);
}

void PrinterInputsOutputs::operatorConfirm()
{
    QString valueInHex= "@W2" + QString("%1").arg(myData[1].ouData , 8, 16,  QLatin1Char( '0' )) + "$\r\n";
    qDebug() << "Send to serial:[" << valueInHex.toUpper() << "]\r";

    QByteArray ba = valueInHex.toUpper().toLocal8Bit();
    const char *c_str2 = ba.data();
    int l = ba.length();

    qserialPort.write(c_str2,l);
}

bool PrinterInputsOutputs::getInputs(int tab, int pos)
{
    bool ret = false;
    ret = myData[tab].inData & (1<<pos);
    return ret;
}

bool PrinterInputsOutputs::getOutput(int tab, int pos)
{
    bool ret = false;
    ret = myData[tab].ouData & (1<<pos);
    return ret;
}

void PrinterInputsOutputs::printerConfirm()
{
    QString valueInHex= "@W1" + QString("%1").arg(myData[0].ouData , 8, 16,  QLatin1Char( '0' )) + "$\r\n";
    qDebug() << "Send to serial:[" << valueInHex.toUpper() << "]\r";

    QByteArray ba = valueInHex.toUpper().toLocal8Bit();
    const char *c_str2 = ba.data();
    int l = ba.length();

    qserialPort.write(c_str2,l);
}

void PrinterInputsOutputs::inputSetData(int tab, int pos, int b)
{
    if(tab<0 || tab>2) return;
    if(b)
        myData[tab].inData |= (1 << pos);
    else
        myData[tab].inData &= ~(1 << pos);

    emit setInputs();
}

void PrinterInputsOutputs::outputSetData(int tab, int pos, int b)
{
    if(tab<0 || tab>2) return;
    if(b)
        myData[tab].ouData |= (1 << pos);
    else
        myData[tab].ouData &= ~(1 << pos);
}

