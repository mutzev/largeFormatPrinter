#include "keypress.h"

KeyPress::KeyPress(QWidget *parent)
{
    qDebug() << "KP init" << parent;
}

void KeyPress::keyPressEvent(QKeyEvent *event)
{
    qDebug() << "KP event" << event;
    emit keyPressEvent(event);
}

