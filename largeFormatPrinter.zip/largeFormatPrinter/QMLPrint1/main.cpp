#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include "gclib.h"
#include "gclibo.h"
#include <QDebug>
#include <QThread>

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);
    //QQmlApplicationEngine engine;

    GCon g = 0;
    GOpen("192.168.0.2", &g);

    char buf[G_SMALL_BUFFER]; //traffic buffer
    //int rc = GMessage(g, buf, G_SMALL_BUFFER);
    int rc = GInfo(g,buf,G_SMALL_BUFFER);

    qDebug() << "g:" << g;
    qDebug() << "rc:" << rc;
    qDebug() << "buf:" << buf;

   // engine.load(QUrl(QStringLiteral("qrc:/main.qml")));
    return app.exec();
}





/*
#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include "gclib.h"
#include "gclibo.h"
#include <QDebug>
#include <QThread>

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;
    const QUrl url(u"qrc:/main.qml"_qs);
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreated,
                     &app, [url](QObject *obj, const QUrl &objUrl) {
        if (!obj && url == objUrl)
            QCoreApplication::exit(-1);
    }, Qt::QueuedConnection);
    engine.load(url);

    GCon g = 0;
    GOpen("192.168.0.2", &g);
    qDebug() << "error g:" << g;

    if(g == G_NO_ERROR) {
        char buf[G_SMALL_BUFFER]; //traffic buffer
        int rc = GInfo(g,buf,G_SMALL_BUFFER);

        qDebug() << "g:" << g;
        qDebug() << "rc:" << rc;
        qDebug() << "buf:" << buf;
    }
    else
    {
        qDebug() << "error g:" << g;
    }

    return app.exec();
}
*/
