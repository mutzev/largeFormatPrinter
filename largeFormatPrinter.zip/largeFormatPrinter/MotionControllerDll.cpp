// new
#include <Windows.h>
#include <iostream>
#include <conio.h>
#include <fstream>
#include <algorithm>

#include <ppltasks.h>
#include <iostream>

#include "gclib.h"
#include "gclibo.h" //by including the open-source header, all other headers are pulled in.

#include "MotionControllerDll.h"
#include "UvLampSwathCommand.h"
#include "CustomSettingsExample.h"
#include "TemperatureInfos.h"
#include "ProgressInfo.h"
#include "JobGroupSizeCommand.h"
#include <mutex>

#include <vector>
#include <algorithm>
#include <numeric>
#include <future>
#include <string>
#include <mutex>
#include <thread> 

using namespace concurrency;
using namespace std;

#pragma comment(lib, "Ws2_32.lib")
#pragma comment(lib, "gclib.lib")
#pragma comment(lib, "gclibo.lib")

enum GALIL_COMMAND
{
    GC_Notting = 0,
    GC_GoHomeA,
    GC_GoHomeB,
    GC_SetSpeedA,
    GC_SetSpeedB,
    GC_SetPosA,
    GC_SetPosB,
    GC_GetStatusA,
    GC_GetStatusB,
    GC_StopA,
    GC_StopUrgentA,
    GC_StopB,
    GC_eStop,
    GC_StopUrgentB
};

string GALIL_COMMAND_STRING[15] =
{
    "GC_Notting",
    "GC_GoHomeA",
    "GC_GoHomeB",
    "GC_SetSpeedA",
    "GC_SetSpeedB",
    "GC_SetPosA",
    "GC_SetPosB",
    "GC_GetStatusA",
    "GC_GetStatusB",
    "GC_StopA",
    "GC_StopB",
    "GC_StopUrgentA",
    "GC_StopUrgentB",
    "GC_eStop",
    "\0"
};

typedef struct
{
    GCon ghandleStatus;
    GCon ghandleCommand;
    // bool gInit;
    bool isHomedA;
    bool isHomedB;
    char gIP[16];
    bool threadLoop;
    bool doLog;
    double readAPos;
    double readBPos;
    int aStat;
    int bStat;
    int waitInterRequestUS;
    double aPos;
    double bPos;
    double gaAxis;
    double gbAxis;
    double SpeedA;
    double SpeedB;
    double xPos;
    bool xRel;
    char gLogFileName[256];
    std::ifstream gLogFile;
    int direction;
    int TS;
    double HomeSpeedA;
    double HomeSpeedB;
    long SoftLimitA_FL;
    long SoftLimitA_BL;
    long SpeedCoefA;
    long SpeedCoefB;
    bool FLS;
    bool BLS;
    bool HLS;
    bool eStop;
    int eStopMask;
    bool eStopInvert;
} MYTHREAD, * PMYTHREAD;

static LogDelegate LogDel = NULL;
static std::mutex LogMutex;

static PMYTHREAD pMyThrInfo;

static long globalCSnt = 0;

void GalilCheck(GReturn rc, GCon g);
bool getGalilConfig(void);
const char* galilGetErrorString(GReturn x);
void DoLog(const char* format, ...);
void doMyLog(const char* format);
 
/*
BOOL WINAPI DllMain(
    HINSTANCE hinstDLL,  // handle to DLL module
    DWORD fdwReason,     // reason for calling function
    LPVOID lpReserved)  // reserved
{

    DoLog("*** moution dll dll main *** %ld",fdwReason);

    // Perform actions based on the reason for calling.
    switch (fdwReason)
    {
    case DLL_PROCESS_ATTACH:
        // Initialize once for each new process.
        // Return FALSE to fail DLL load.
        break;

    case DLL_THREAD_ATTACH:
        // Do thread-specific initialization.
        break;

    case DLL_THREAD_DETACH:
        // Do thread-specific cleanup.
        break;

    case DLL_PROCESS_DETACH:
        // Perform any necessary cleanup.
        break;
    }
    
   // int msgboxID = MessageBox(NULL,"Resource not available\nDo you want to try again?","Account Details",MB_OK);
    cout << "*** moution controll dll entry point *** " << ++globalCSnt << std::endl;

    return TRUE;  // Successful DLL_PROCESS_ATTACH.
}
*/


void GalilCheck(GReturn rc, GCon g)
{
    char logBuffer[256];
    if (rc != G_NO_ERROR)
    {
        sprintf_s(logBuffer, ">>> galil error '%d' %s <<<\n", rc, galilGetErrorString(rc));
        doMyLog(logBuffer);
        if (g)
        {
            switch (rc)
            {
            case G_BAD_RESPONSE_QUESTION_MARK:
            {
                char buf[G_SMALL_BUFFER]; //traffic buffer
                char* trimmed; //trimmed string pointer

                GReturn x = GCmdT(g, "TC1", buf, sizeof(buf), &trimmed);
                sprintf_s(logBuffer, ">>> TC1: [%d] [%s] <<<\n", x, trimmed);
                doMyLog(logBuffer);
            }
            break;
            default:
                break;
            }
        }
        else
        {
            // DoLog("---galil not opened\n---------------\n");
        }
    }
}

void doMyLog(const char* format)
{
    std::ofstream x(pMyThrInfo->gLogFileName, std::ofstream::out | std::ofstream::app);

    if (x.is_open())
    {
        SYSTEMTIME  sysTime;
        GetLocalTime(&sysTime);
        char timeBuffer[128];
        sprintf_s(timeBuffer, "%02d-%02d-%04d %02d:%02d:%02d.%03d", sysTime.wDay, sysTime.wMonth, sysTime.wYear, sysTime.wHour, sysTime.wMinute, sysTime.wSecond, sysTime.wMilliseconds);
        x._Seekend;
        x << timeBuffer << endl << format;
        x.close();
    }

    DoLog(format);

    return;
}

void GCCommandFunc(GALIL_COMMAND gcCommand)
{
    std::string logOutputString = "";
    char buf[256];
    memset(buf, 0, 256);

    if (!pMyThrInfo->ghandleCommand)
    {
        Sleep(1000);
        GalilCheck(GOpen(pMyThrInfo->gIP, &pMyThrInfo->ghandleCommand), pMyThrInfo->ghandleCommand);
        if (pMyThrInfo->doLog)
        {
            if (pMyThrInfo->ghandleCommand)
                std::cout << "Galil open command thread successfull!" << std::endl;
            else
                std::cout << "Galil open command FAILED!!!" << std::endl;
        }
    }

    if (pMyThrInfo->ghandleCommand)
    {

        logOutputString.append(">>> try to send:");
        logOutputString.append(GALIL_COMMAND_STRING[gcCommand]);

        sprintf_s(buf, " aPOS//gaAxis:%5.2f APOS:%5.2f GAXIS:%5.2f ", pMyThrInfo->aPos / pMyThrInfo->gaAxis, pMyThrInfo->aPos, pMyThrInfo->gaAxis);
        logOutputString.append(buf);

        memset(buf, 0, 256);
        sprintf_s(buf, " bPOS//gbAxis:%5.2f BPOS:%5.2f GBXIS:%5.2f\n", pMyThrInfo->bPos / pMyThrInfo->gbAxis, pMyThrInfo->bPos, pMyThrInfo->gbAxis);
        logOutputString.append(buf);

        memset(buf, 0, 256);

        switch (gcCommand)
        {
        case GC_SetSpeedA:
            sprintf_s(buf, "SP %ld", (long)pMyThrInfo->SpeedA * pMyThrInfo->SpeedCoefA);
            GalilCheck(GCmd(pMyThrInfo->ghandleCommand, buf), pMyThrInfo->ghandleCommand);
            logOutputString.append(buf);
            break;
        case GC_SetSpeedB:
            sprintf_s(buf, "SP ,%ld", (long)pMyThrInfo->SpeedB * pMyThrInfo->SpeedCoefB);
            GalilCheck(GCmd(pMyThrInfo->ghandleCommand, buf), pMyThrInfo->ghandleCommand);
            logOutputString.append(buf);
            break;
        case GC_SetPosA:
            GalilCheck(GCmd(pMyThrInfo->ghandleCommand, "SH A"), pMyThrInfo->ghandleCommand);
            sprintf_s(buf, "%s %ld", pMyThrInfo->xRel ? "PR" : "PA", (long)pMyThrInfo->xPos);
            GalilCheck(GCmd(pMyThrInfo->ghandleCommand, buf), pMyThrInfo->ghandleCommand);
            GalilCheck(GCmd(pMyThrInfo->ghandleCommand, "BG A"), pMyThrInfo->ghandleCommand);
            {
                char xyz[128];
                sprintf_s(xyz, "\ndirection %d\n", pMyThrInfo->direction);
                logOutputString.append(xyz);
            }

            logOutputString.append("SH A\n");
            logOutputString.append(buf);
            logOutputString.append("\nBG A");
            break;
        case GC_SetPosB:
            GalilCheck(GCmd(pMyThrInfo->ghandleCommand, "SH B"), pMyThrInfo->ghandleCommand);
            sprintf_s(buf, "%s ,%ld", pMyThrInfo->xRel ? "PR" : "PA", (long)pMyThrInfo->xPos);
            GalilCheck(GCmd(pMyThrInfo->ghandleCommand, buf), pMyThrInfo->ghandleCommand);
            GalilCheck(GCmd(pMyThrInfo->ghandleCommand, "BG B"), pMyThrInfo->ghandleCommand);
            logOutputString.append("SH B\n");
            logOutputString.append(buf);
            logOutputString.append("\nBG B");
            break;
        case GC_GoHomeA:
        {
            pMyThrInfo->isHomedA = false;
            GalilCheck(GCmd(pMyThrInfo->ghandleCommand, "LDA=2"), pMyThrInfo->ghandleCommand); // LDA=0 =ENABLE, =1 FWRD - DISABLE, =2 BACK DISABLE, 3 DISABLE BOTH

            GalilCheck(GCmd(pMyThrInfo->ghandleCommand, "FL 2147483647"), pMyThrInfo->ghandleCommand);
            GalilCheck(GCmd(pMyThrInfo->ghandleCommand, "BL -2147483647"), pMyThrInfo->ghandleCommand);
            // HV - home velocity
            sprintf_s(buf, "SP %ld", (long)pMyThrInfo->HomeSpeedA * pMyThrInfo->SpeedCoefA);
            GalilCheck(GCmd(pMyThrInfo->ghandleCommand, buf), pMyThrInfo->ghandleCommand);

            GalilCheck(GCmd(pMyThrInfo->ghandleCommand, "SH A"), pMyThrInfo->ghandleCommand);
            GalilCheck(GCmd(pMyThrInfo->ghandleCommand, "HM A"), pMyThrInfo->ghandleCommand);
            GalilCheck(GCmd(pMyThrInfo->ghandleCommand, "BG A"), pMyThrInfo->ghandleCommand);
            logOutputString.append("LDA=2\nFL 2147483647\nBL -2147483647\nSH A\nHM A\nBG A");
        }
        break;
        case GC_GoHomeB:
            GalilCheck(GCmd(pMyThrInfo->ghandleCommand, "SH B"), pMyThrInfo->ghandleCommand);
            GalilCheck(GCmd(pMyThrInfo->ghandleCommand, "HM B"), pMyThrInfo->ghandleCommand);
            GalilCheck(GCmd(pMyThrInfo->ghandleCommand, "BG B"), pMyThrInfo->ghandleCommand);
            logOutputString.append("SH B\nHM B\nBG B");
            break;
        case GC_eStop:
            break;
        case GC_StopA:
            GalilCheck(GCmd(pMyThrInfo->ghandleCommand, "ST A"), pMyThrInfo->ghandleCommand);
            logOutputString.append("ST A");
            break;
        case GC_StopB:
            GalilCheck(GCmd(pMyThrInfo->ghandleCommand, "ST B"), pMyThrInfo->ghandleCommand);
            logOutputString.append("ST B");
            break;
        case GC_StopUrgentA:
            GalilCheck(GCmd(pMyThrInfo->ghandleCommand, "AB 1"), pMyThrInfo->ghandleCommand);
            logOutputString.append("AB 1"); // STOP ALL MOUTION AXIS
            break;
        case GC_StopUrgentB:
            GalilCheck(GCmd(pMyThrInfo->ghandleCommand, "AB 1"), pMyThrInfo->ghandleCommand);
            logOutputString.append("AB 1");
            break;
        default:
            break;
        }
    }
    else
    {
        logOutputString.append(">>> Galil not opened. Command:");
        logOutputString.append(GALIL_COMMAND_STRING[gcCommand]);
        logOutputString.append(" failed.");
    }

    logOutputString.append("<<<\n");

    doMyLog((char*)&logOutputString[0]);

    return;
}


DWORD WINAPI PingThread(LPVOID lpParam)
{

    while (true)
    {
        DoLog("is a live...\n");
        Sleep(1000);
    }
}

DWORD WINAPI ThreadFunc(LPVOID lpParam)
{
    PMYTHREAD pData = (PMYTHREAD)lpParam;
    bool isConfigRead = getGalilConfig();

    if (!isConfigRead)
    {
        DoLog("*** moution dll ***\n!!!error read config !!!\n");
        return 0;
    }

    while (pData->threadLoop)
    {
        if (!pMyThrInfo->ghandleStatus)
        {
            Sleep(1000);
            if (pData->doLog)
            {
                std::cout << "Try to open Galil IP:" << pData->gIP << std::endl;
            }

            GalilCheck(GOpen(pData->gIP, &pMyThrInfo->ghandleStatus), pMyThrInfo->ghandleStatus);
            if (pData->doLog)
            {
                if (pMyThrInfo->ghandleStatus)
                    std::cout << "Galil open status thread successfull!" << std::endl;
                else
                    std::cout << "Galil open status FAILED!!!" << std::endl;
            }
        }
        if (pMyThrInfo->ghandleStatus)
        {
            /*
            Bit 7     Axis in motion if high
            Bit 6     Axis error exceeds error limit if high
            Bit 5     A motor off if high
            Bit 4     Undefined
            Bit 3     Forward Limit Switch Status inactive if high
            Bit 2     Reverse Limit Switch Status inactive if high
            Bit 1     Home A Switch Status
            Bit 0     Latched Note: For active high
            */

            int TI0 = 0;
            int switchStatusA = 0;
            GalilCheck(GCmdI(pMyThrInfo->ghandleStatus, "TI0", &TI0), pMyThrInfo->ghandleStatus);
            GalilCheck(GCmdI(pMyThrInfo->ghandleStatus, "TS A", &switchStatusA), pMyThrInfo->ghandleStatus);

            bool FLS, BLS, HLS;
            FLS = switchStatusA & 8;
            BLS = switchStatusA & 4;
            HLS = switchStatusA & 2;

            pMyThrInfo->HLS = HLS ^ 1;
            pMyThrInfo->BLS = BLS ^ 1;
            pMyThrInfo->FLS = FLS ^ 1;

            pData->eStop = TI0 & pData->eStopMask;
            if (pData->eStopInvert)
            {
                if (pData->eStop)
                    pData->eStop = false;
                else
                    pData->eStop = true;
            }

            //DoLog("ti0 %d estop %d emask %d einvert %d", TI0, pData->eStop, pData->eStopMask, pData->eStopInvert);
            std::cout << "*** ti0 " << TI0 << " estop " << pData->eStop << " emask " << pData->eStopMask << " erevert " << pData->eStopInvert << " ***" << std::endl;

            // todo must get limit switches
            // std::cout << "*** FLS " << FLS <<" RLS " << RLS << " HLS " << HLS << " ***" << std::endl;

            GalilCheck(GCmdD(pMyThrInfo->ghandleStatus, "RP A", &pData->aPos), pMyThrInfo->ghandleStatus);
            GalilCheck(GCmdI(pMyThrInfo->ghandleStatus, "SC A", &pData->aStat), pMyThrInfo->ghandleStatus);
            GalilCheck(GCmdD(pMyThrInfo->ghandleStatus, "RP B", &pData->bPos), pMyThrInfo->ghandleStatus);
            GalilCheck(GCmdI(pMyThrInfo->ghandleStatus, "SC B", &pData->bStat), pMyThrInfo->ghandleStatus);

            if (pData->aStat == 2 || pData->aStat == 3)
            {
                // limit switch stop
            }

            //if (pData->aStat == 6)
            if(pData->eStop)
            {
                pData->isHomedA = false;
                pData->isHomedB = false;
            }

            if (pData->aStat == 10)
            {
                char buf[256];

                GalilCheck(GCmd(pMyThrInfo->ghandleCommand, "LDA=0"), pMyThrInfo->ghandleCommand); // LDA=0 =ENABLE, =1 FWRD - DISABLE, =2 BACK DISABLE, 3 DISABLE BOTH

                memset(buf, 0, 256);
                sprintf_s(buf, "FL %ld", (long)pMyThrInfo->SoftLimitA_FL * (long)pMyThrInfo->gaAxis);
                GalilCheck(GCmd(pMyThrInfo->ghandleStatus, buf), pMyThrInfo->ghandleStatus);

                memset(buf, 0, 256);
                sprintf_s(buf, "BL %ld", (long)pMyThrInfo->SoftLimitA_BL * (long)pMyThrInfo->gaAxis);
                GalilCheck(GCmd(pMyThrInfo->ghandleStatus, buf), pMyThrInfo->ghandleStatus);

                memset(buf, 0, 256);
                sprintf_s(buf, "SP %ld", (long)(pMyThrInfo->SpeedA * pMyThrInfo->SpeedCoefA));
                GalilCheck(GCmd(pMyThrInfo->ghandleStatus, buf), pMyThrInfo->ghandleStatus);

                pData->isHomedA = true;
            }
            if (pData->bStat == 10)
            {
                pData->isHomedB = true;
            }
            // GalilCheck(GCmdI(pMyThrInfo->ghandleStatus, "TS", &pData->TS), pMyThrInfo->ghandleStatus);
           // DoLog("tell status: %d\n", pData->TS);
            Sleep(pMyThrInfo->waitInterRequestUS);
            // Sleep(1000);
        }
    }

    return 0;
}

void DoLog(const char * format, ...) {
    if (LogDel == NULL) {
        return;
    }
    std::lock_guard<std::mutex> lck(LogMutex);

    va_list args;
    va_start(args, format);
    size_t needed = vsnprintf(NULL, 0, format, args) + 1;
    char* buffer = (char*)malloc(needed);
    vsprintf_s(buffer, needed, format, args);
    SYSTEMTIME  sysTime;
    GetLocalTime(&sysTime);
    char* context;
    char* token = strtok_s(buffer, "\n", &context); //-- Split up each line into a separate message
    while (token != NULL) {
        size_t time = snprintf(NULL, 0, "%02d-%02d-%04d %02d:%02d:%02d.%03d %s", sysTime.wDay, sysTime.wMonth, sysTime.wYear, sysTime.wHour, sysTime.wMinute, sysTime.wSecond, sysTime.wMilliseconds, token) + 1;
        char* timeBuffer = (char*)malloc(time);
        sprintf_s(timeBuffer, time, "%02d-%02d-%04d %02d:%02d:%02d.%03d %s", sysTime.wDay, sysTime.wMonth, sysTime.wYear, sysTime.wHour, sysTime.wMinute, sysTime.wSecond, sysTime.wMilliseconds, token);
        LogDel(timeBuffer);
        free(timeBuffer);
        token = strtok_s(NULL, "\n", &context);
    }
    free(buffer);
    va_end(args);
}


MOTION_IFTYPE void MOTION_CALLCONV SetLogDelegate(LogDelegate apDelegate) {
    // When called:
    //  Called immediately after the dll has been loaded, when the SwathIPCServer.exe is run with
    //  the -ml command line option (the 'setMmiLogDelgate' flag in IPCServerLauncher.Start)
    //
    // Purpose:
    //  Provides a function pointer which the dll can use to send diagnostic messages back to
    //  the parent application (i.e. MetScan)
    //
    // Notes:
    //  This function is optional, if it's not found in the dll's export table this is not
    //  considered to be an error condition
    //
    LogDel = apDelegate;
    DoLog("---MotionDLL---\nSetLogDelegate\n---------------\n");
}

/***********************************************************************************/

MOTION_IFTYPE eMotionResult MOTION_CALLCONV GetInterfaceVersion(uint32_t* apVer, uint32_t* apFeaturesSupported) {
    // When called:
    // Called at any time.  
    // Note that GetInterfaceVersion can be called **before** Initialise.
    //
    // The upper 16 bits of apVer must be set with the MMI interface version 
    // as defined in MotionResult.h.
    //
    // The lower 16 bits of apVer should uniquely identify this version of the
    // plugin software.
    //
    // apFeaturesSupported must be set with a bitmask indicating the high level features
    // which the plugin supports.  For most plugins this will just be MMI_Feature_Motors.
    //
    const uint16_t KVer_Dll       = 0x01;
    *apVer = ((uint32_t)KVer_MMI_Interface << 16) | KVer_Dll;
    *apFeaturesSupported = MMI_Feature_Motors; // | MMI_Feature_InkPumps;
    // 
    //
    // Returns:
    // MRES_OK


    pMyThrInfo = (PMYTHREAD)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, sizeof(MYTHREAD));

    pMyThrInfo->threadLoop = true;
    pMyThrInfo->doLog = true;
    pMyThrInfo->waitInterRequestUS = 5;

    HANDLE pingThr = CreateThread(NULL, 0, PingThread, 0, 0, NULL);
    HANDLE thread = CreateThread(NULL, 0, ThreadFunc, pMyThrInfo, 0, NULL);

    DoLog("---MotionDLL threaded !!!E-STOP!!!---\nGetInterfaceVersion 0x%08x 0x%08x\n---------------\n", *apVer, *apFeaturesSupported);
    return MRES_OK;
}

/***********************************************************************************/

MOTION_IFTYPE eMotionResult MOTION_CALLCONV Initialise(const char* apCfgFilePath) {
    // When called:
    // Called when the application is first started.

    // Purpose:
    // Connect to hardware and perform any other initialisation of variables.
    // apCfgFilePath is for future use and will currently be an empty string.
    
    // Notes:
    // Can block the current thread if necessary.

    // Returns:
    // MRES_OK if successful. 
    // MRES_FAULT for an unrecoverable fault.
    DoLog("---MotionDLL---\nInitialise '%s'\n---------------\n", apCfgFilePath);
    return  MRES_OK;
}


/***********************************************************************************/

MOTION_IFTYPE eMotionResult MOTION_CALLCONV ShutDown() {
    // When called:
    // Called at the end of the application. 
    // 
    // Purpose:
    // Any code needed to wind down and disconnect the hardware cleanly can be
    // added here.
    //
    // Notes:
    // This function should block the thread until the shutdown is complete.
    //
    // This function does not need to move the print carriage to home position,
    // as this will be done by the application.
    //
    // Returns:
    // MRES_OK only. The shutdown process can not prevent the application from 
    // stopping.
    DoLog("---MotionDLL---\nShutDown\n---------------\n");
    return 	 MRES_OK;
}

/***********************************************************************************/

MOTION_IFTYPE eMotionResult MOTION_CALLCONV MoveHome(eMotionAxis aAxis) {
    // When called:
    // - when the application is first started, after Initialise.
    // - occasionally during normal operation, to rehome on the home sensor.
    
    // Purpose:
    // Go through a homing routine to find the home sensor.
    
    // Notes:
    // Can block the current thread if necessary.
    
    // Returns:
    // MRES_OK if successful. 
    // MRES_BUSY if the print carriage is already moving.
    // MRES_FAULT for an unrecoverable fault.
    DoLog("---MotionDLL---\nMoveHome %d\n---------------\n", aAxis);
    switch (aAxis)
    {
    case Axis1:
        if (pMyThrInfo->aStat == 0)
        {
            return MRES_BUSY;
        }
        // must move to forward and then go home!
        if (pMyThrInfo->BLS || pMyThrInfo->HLS)
        {
            return MRES_OK;
        }
        pMyThrInfo->isHomedA = false;

        GCCommandFunc(GC_GoHomeA);
        return MRES_OK;
    case Axis2:
        GCCommandFunc(GC_GoHomeB);
        return MRES_OK;
    default:
        break;
    }

    return MRES_FAULT;
}

/***********************************************************************************/

MOTION_IFTYPE eMotionResult MOTION_CALLCONV MoveTo(eMotionAxis aAxis, eMoveOption aMvOpt, double aDist_mm) {
    // When called:
    // Called whenever the application wants the printer carriage to move.
    //
    // Purpose:
    // This function will send the print carriage to the designated position in mm
    //
    // The move can be absolute or relative, depending on the value of aMvOpt
    //
    // MV_DistAbs selects an absolute move. For example, calling this function with aDist_mm=10 will
    // send the axis to 10mm from the home position. Calling this function with aDist_mm=10 a second time 
    // will not move the axis, as it is already at aDist_mm=10.
    //
    // MV_DistRel selects a relative move. For example, calling this function with aDist_mm=10 will 
    // move the axis 10mm from its current position. Calling this function with aDist_mm=10 a second time 
    // will move the axis another 10mm.
    //
    // Continuous movement: if MMI_Feature_ContininuousMovement is set to the apFeaturesSupported in GetInterfaceVersion
    // continuous movement controls will be enabled in MetScan UI. The continuous movement command uses +/- infinity
    // as the distance value. Continuous movement is stopped using MoveCancel method.
    // The following example code demonstrates continuous command detection:

    if (aDist_mm == std::numeric_limits<double>::infinity()) {
        // Positive continuous motion command
    }
    if (aDist_mm == -std::numeric_limits<double>::infinity()) {
        // Negative continuous motion command
    }

    //
    // Notes:
    // This function should start the motion sequence and then return. It should not block 
    // while the axis is moving.  The application will poll MoveStatus to find out when the
    // move has completed
    //
    // Returns:
    // MRES_OK if the motion sequence was started.
    // MRES_INTERRUPT if the motion was cancelled.
    // MOTION_BUSY if the print carriage is already moving.
    // MRES_FAULT for an unrecoverable fault.
    // MRES_NOTINIT if the motion controller is not initialised. 
    DoLog("---MotionDLL---\nMoveTo %d %d %.2f\n---------------\n", aAxis, aMvOpt, aDist_mm);    


    switch (aAxis)
    {
    case Axis1:
    {

        /*
        0 - Motors are running
        1 - Motors stopped at commanded independent position
        2 - Decelerating or stopped by FWD limit switches
        3 - Decelerating or stopped by REV limit switches
        4 - Decelerating or stopped by Stop Command (ST)
        6 - Stopped by Abort input
        7 - Stopped by Abort command (AB
        8 - Decelerating or stopped by Off-on-Error (OE1)
        MRES_INTERRUPT
        */

        if (pMyThrInfo->aStat == 2 || pMyThrInfo->aStat == 3 || pMyThrInfo->aStat == 8)
        {
            // return MRES_INTERRUPT;
        }

        if (pMyThrInfo->aStat == 0) // if moved
        {
            return MRES_BUSY;
        }
        // if (!pMyThrInfo->gInit)
        // {
        //     return MRES_NOTINIT;
        // }
        pMyThrInfo->xRel = (aMvOpt == MV_DistRel);

        pMyThrInfo->direction = aMvOpt;

        pMyThrInfo->xPos = aDist_mm * pMyThrInfo->gaAxis;
        GCCommandFunc(GC_SetPosA);
    }
    return 	MRES_OK;
    case Axis2:
    {
        if (pMyThrInfo->bStat == 0)
        {
            return MRES_BUSY;
        }
        // if (!pMyThrInfo->gInit)
        // {
        //     return MRES_NOTINIT;
        // }

        pMyThrInfo->xRel = (aMvOpt == MV_DistRel);
        pMyThrInfo->xPos = aDist_mm * pMyThrInfo->gbAxis;
        GCCommandFunc(GC_SetPosB);
    }
    return 	MRES_OK;
    default:
        break;
    }

    //
    // Notes:
    // This function should start the motion sequence and then return. It should not block 
    // while the axis is moving.  The application will poll MoveStatus to find out when the
    // move has completed
    //
    // Returns:
    // MRES_OK if the motion sequence was started.
    // MRES_INTERRUPT if the motion was cancelled.
    // MOTION_BUSY if the print carriage is already moving.
    // MRES_FAULT for an unrecoverable fault.
    // MRES_NOTINIT if the motion controller is not initialised. 
    // DoLog("---***MotionDLL---\nMoveTo %d %d %.2f\n---------------\n", aAxis, aMvOpt, aDist_mm);    
    return 	MRES_OK;
}

/***********************************************************************************/

MOTION_IFTYPE eMotionResult MOTION_CALLCONV MoveCancel(eMotionAxis aAxis, eCancelOption aOption) {
    // When called:
    // Can be called at any point. 
    //
    // Purpose:
    // Cancel an in-progress move on the axis.
    // Also used as a general cancel for any non-axis movement which the plugin may be controlling,
    // with aAxis set to AxisNone (0)
    //
    // Returns:
    // MRES_OK if the Cancel sequence was started, or if there's nothing to cancel
    // MRES_FAULT otherwise.
    DoLog("---MotionDLL---\nMoveCancel %d %d\n---------------\n", aAxis, aOption);    

    switch (aAxis)
    {
    case Axis1:
        if (aOption == CANCEL_NORMAL)
            GCCommandFunc(GC_StopA);
        if (aOption == CANCEL_URGENT)
            GCCommandFunc(GC_StopUrgentA);
        break;
    case Axis2:
        if (aOption == CANCEL_NORMAL)
            GCCommandFunc(GC_StopB);
        if (aOption == CANCEL_URGENT)
            GCCommandFunc(GC_StopUrgentB);
        break;
    }

    return MRES_OK;

}

/***********************************************************************************/

MOTION_IFTYPE eMotionResult MOTION_CALLCONV MoveStatus(eMotionAxis aAxis, TMoveStat* apMoveStat) {
    // When called:
    // At any time.  For example, after sending a motion command (Home, MoveTo), the application
    // checks whether the command has finished or not, and the current position of the axis.
    //
    // Purpose:
    // This function is used to determine when it is safe to send more motion commands.
    // The returned data is also used for the application to monitor the health
    // of the motion system.
    //
    // Returns:
    // MRES_OK if successful and motion is operating normally. 
    // MRES_FAULT if a serious fault occurred (i.e. the motion has jammed).
    // MRES_STRUCTSIZE_MISMATCH if the size of TMoveStat is incorrect (to protect against
    // version incompatibility)

    if ( apMoveStat->structSize != sizeof(TMoveStat) ) {
        DoLog("---MotionDLL---\nTMoveStat size mismatch\n");
        return MRES_STRUCTSIZE_MISMATCH;
    }

/*
    // -- Set some dummy data --
    switch ( aAxis ) {
    case Axis1:
        // Axis is idle
        apMoveStat->axisState = AxS_Idle;
        apMoveStat->dist_mm = 123;
        // Axis has previously been successfully homed
        apMoveStat->axisHomed = true;
        // Home, limit+ and limit- sensors fitted; limit- active
        apMoveStat->activeSensorsBmp = (1 << MtrSens_MinPosLimit);
        apMoveStat->assignedSensorsBmp = (1 << MtrSens_Home) | (1 << MtrSens_MinPosLimit) | (1 << MtrSens_MaxPosLimit);
        break;
    case Axis2:
        // Move is in progress on the axis
        apMoveStat->axisState = AxS_Busy;
        apMoveStat->dist_mm = 456;
        apMoveStat->axisHomed = false;
        // No sensors on the axis
        apMoveStat->activeSensorsBmp = 0;
        apMoveStat->assignedSensorsBmp = 0;
        break;
    case Axis3:
        // Axis is idle
        apMoveStat->axisState = AxS_Idle;
        apMoveStat->dist_mm = 0;
        apMoveStat->axisHomed = true;
        // Axis has home sensor only; home sensor is active
        apMoveStat->activeSensorsBmp = (1 << MtrSens_Home);
        apMoveStat->assignedSensorsBmp = (1 << MtrSens_Home);
        break;
    }
*/
    /*
    typedef enum {
   AxS_Invalid = 0x00000000,   // invalid state, motion system is not initialised
   AxS_Idle = 0x00000001,   // idle, can accept MoveXXX commands
   AxS_Busy = 0x00000002,   // busy, motor is moving
   AxS_Estop = 0x00000003,   // estop is activate
} eAxisSate;
    
    */


    // -- Set some dummy data --
    switch (aAxis) {
    case Axis1:
    {
        if (pMyThrInfo->aStat == 0)
        {
            apMoveStat->axisState = AxS_Busy;  // check if move and store busy!!!
        }
        else
        {
            apMoveStat->axisState = AxS_Idle;  // check if move and store busy!!!
        }

        apMoveStat->axisHomed = pMyThrInfo->isHomedA;

        //doMyLog("*** POS:%5.2f APOS:%5.2f GAXIS:%5.2f", pMyThrInfo->aPos / pMyThrInfo->gaAxis, pMyThrInfo->aPos, pMyThrInfo->gaAxis);
            // 1 home
            // 2 backward
            // 4 forward

        //    MtrSens_Home = 0x00000000,   // Bit 0, state of the motor "home" sensor
        //    MtrSens_MinPosLimit = 0x00000001,   // Bit 1, state of the motor limit switch at min. position
        //    MtrSens_MaxPosLimit = 0x00000002,   // Bit 2, state of the motor limit switch at max. position
        
        apMoveStat->dist_mm = pMyThrInfo->aPos / pMyThrInfo->gaAxis;
        int status = 0;
        if (pMyThrInfo->HLS) status |= 1;
        if (pMyThrInfo->isHomedA)
        {
            if (pMyThrInfo->BLS) status |= 2;
        }
        if (pMyThrInfo->FLS) status |= 4;

        apMoveStat->activeSensorsBmp = status;
      //  apMoveStat->assignedSensorsBmp = 0x07; // 0xff;
        apMoveStat->assignedSensorsBmp = (1 << MtrSens_Home) | (1 << MtrSens_MinPosLimit) | (1 << MtrSens_MaxPosLimit);

               // apMoveStat->activeSensorsBmp = (1 << MtrSens_MinPosLimit);

        if (pMyThrInfo->eStop)
        {
            pMyThrInfo->isHomedA = false;
            apMoveStat->axisHomed = pMyThrInfo->isHomedA;
            apMoveStat->axisState = AxS_Estop;
           // return MRES_OK;
        }

    }
    break;
    case Axis2:
    {
        if (pMyThrInfo->bStat == 0)
        {
            apMoveStat->axisState = AxS_Busy;  // check if move and store busy!!!
        }
        else
        {
            apMoveStat->axisState = AxS_Idle;  // check if move and store busy!!!
        }
        // if (pMyThrInfo->bStat == 10)
        // {
        apMoveStat->axisHomed = pMyThrInfo->isHomedB;
        //}
        //else
        //{
        //    apMoveStat->axisHomed = false;
        //}

     //   doMyLog("POS:%5.2f BPOS:%5.2f GBXIS:%5.2f", pMyThrInfo->bPos / pMyThrInfo->gbAxis, pMyThrInfo->bPos, pMyThrInfo->gbAxis);

        apMoveStat->dist_mm = pMyThrInfo->bPos / pMyThrInfo->gbAxis;
        apMoveStat->activeSensorsBmp = 0;
        apMoveStat->assignedSensorsBmp = 0;
    }

    break;
    default:
        break;
    }

    return 	MRES_OK;
}

/***********************************************************************************/

MOTION_IFTYPE eMotionResult MOTION_CALLCONV MoveSetSpeed(eMotionAxis aAxis, eMSpeedOption aOpt, double aSpeed_mm_s) {
    // When called:
    // At any time, normally when an axis is not in motion.
    //
    // Purpose:
    // This function is used to set the speed of the axis for subsequent moves.
    // If a move is currently in progress the speed should not take effect until the next move
    //
    // Notes:
    // If the requested speed is larger than the maximum allowed speed, the axis speed should be
    // set to the maximum, and MRES_BADPARAM should be returned
    // If the requested speed is smaller than the minimum allowed speed, the axis speed should be
    // set to its minimum, and MRES_BADPARAM should be returned
    //
    // Returns:
    // MRES_OK if the speed was set successfully
    // MRES_BADPARAM if the requested speed was out of range
    DoLog("---MotionDLL---\nMoveSetSpeed %d %d %.2f\n---------------\n", aAxis, aOpt, aSpeed_mm_s);

    switch (aAxis)
    {
        // MAYBE MUST MULTUPLY SPEED * SOME_COEFFICIENT
    case Axis1:
        pMyThrInfo->SpeedA = aSpeed_mm_s;
        GCCommandFunc(GC_SetSpeedA);
        break;
    case Axis2:
        pMyThrInfo->SpeedB = aSpeed_mm_s;
        GCCommandFunc(GC_SetSpeedB);
        break;
    default:
        break;
    }
    return MRES_OK;
}

/***********************************************************************************/

MOTION_IFTYPE eMotionResult MOTION_CALLCONV ControlSetState(eDevice aDev, uint32_t aIndex, int32_t aState) {
    // Purpose:
    // This function can be used to enable implementation specific PLC functionality.
    // It does not need to be implemented for standard motion control.
    //
    switch (aDev)
    {
    case DEV_VacPump:
        break;
    case DEV_InkPump:
        break; 
    default:
        break;
    }
   // DoLog("---MotionDLL---\nControlSetState %d %d %d\n---------------\n", aDev, aIndex, aState);
    //return MRES_UNIMPL;
    return MRES_OK;
}

/***********************************************************************************/

MOTION_IFTYPE eMotionResult MOTION_CALLCONV ControlStatus(eDevice aDev, uint32_t aIndex, int32_t* apState) {
    // Purpose:
    // This function can be used to enable implementation specific PLC status.
    // It does not need to be implemented for standard motion control.
    //
    //DoLog("---MotionDLL---\nControlStatus %d %d\n---------------\n", aDev, aIndex);
   // return MRES_UNIMPL;
    return MRES_OK;
}

/***********************************************************************************/

MOTION_IFTYPE eMotionResult MOTION_CALLCONV GenericControl(int32_t aCommand, int32_t aOption, int32_t aParamSize, uint32_t* apParam) {
    // Purpose:
    // This function can be used to specify plugin specific commands.
    // It does not need to be implemented for standard motion control.
    //
    DoLog("---MotionDLL---\nGenericControl %d %d\n", aCommand, aOption);

    DoLog("%d Params: ", aParamSize);
    for ( int i = 0; i < aParamSize; i++ ) {
        DoLog(" %d ", apParam[i]);
    }
    DoLog("\n---------------\n");
   // return MRES_UNIMPL;
    return MRES_OK;
}

/***********************************************************************************/

MOTION_IFTYPE eMotionResult MOTION_CALLCONV GenericControlStr(int32_t aCommand, int32_t aOption, int32_t aParamSize, char* apParam) {
    // Purpose:
    // This function can be used to specify plugin specific commands.
    // It does not need to be implemented for standard motion control.
    //
    DoLog("---MotionDLL---\nGenericControlStr %d %d\n", aCommand, aOption);

    // Example of parsing UV lamp swath command
    // Beware that example is based on fixed setting class and therefore best to be used as is
    if (aCommand == ECtl_SetUvLampSwathCommand) {
        TUvLampSwathCommand lsc;
        if(!lsc.Initialise(apParam)) {
            DoLog("Failed to parse JSON string for command %d\n", aCommand);
        } else {
            DoLog("Swath command parsed successfully Start: %lf End: %lf Reverse: %d\n", lsc.GetPrintStart(), lsc.GetPrintEnd(), lsc.GetIsReverse());
        }
    }

    // Example of parsing print progress command
    // Beware that example is based on fixed setting class and therefore best to be used as is
    if (aCommand == ECtl_SendPrintProgress) {
        TProgressInfo pi;
        if (!pi.Initialise(apParam)) {
            DoLog("Failed to parse JSON string for command %d\n", aCommand);
        }
        else {
            DoLog("Swath command parsed successfully Swath Printed: %d Swath Total: %d.\n", pi.GetSwathPrinted(), pi.GetSwathTotal());
        }
    }

    // This is example code that can be used for UV lamp settings, cleaning settings,
    // start and end sequences. Please modify it as needed. It is you responsibility to maintain
    // settings parser compatible with the settings you are setting in the MetScan UI
    if (aCommand == ECtl_SetUvLampSettings || aCommand == ECtl_RunCleaningProcedure || aCommand == ECtl_RunStartSequence || aCommand == ECtl_RunEndSequence || aCommand == ECtl_RunGroupEndSequence || aCommand == ECtl_RunQueueEndSequence) {
        TCustomSettingsExample settings;
        if (!settings.Initialise(apParam)) {
            DoLog("Failed to parse JSON string for command %d\n", aCommand);
        } else {
            DoLog("Swath command parsed successfully CyclesNumber: %d Pressure: %lf NeedsWiping: %d\n", settings.GetCyclesNumber(), settings.GetPressure(), settings.GetNeedsWiping());
        }
    }

    // Example of parsing update temperature info command
    // Beware that example is based on fixed setting class and therefore best to be used as is
    if (aCommand == ECtl_UpdateHeadTemperatureInfo) {
        TTemperatureInfos tInfos;
        if (!tInfos.Initialise(apParam)) {
            DoLog("Failed to parse JSON string for command %d\n", aCommand);
        } else {
            std::vector<TTemperatureInfo> resultVec = tInfos.GetVectorOfTemperatureInfos();
            for (std::vector<TTemperatureInfo>::iterator it = resultVec.begin(); it != resultVec.end(); ++it) {
                DoLog("Update temperature info command parsed successfully TargetTemperature: %lf ActualTemperature: %lf\n", it->GetTargetTemperature(), it->GetActualTemperature());
            }
        }
    }

    // Example of parsing print progress command
    // Beware that example is based on fixed setting class and therefore best to be used as is
    if (aCommand == ECtl_SendJobGroupSize) {
        TJobGroupSizeCommand jgs;
        if (!jgs.Initialise(apParam)) {
            DoLog("Failed to parse JSON string for command %d\n", aCommand);
        }
        else {
            DoLog("Swath command parsed successfully Job Group Size: %d.\n", jgs.GetJobGroupSize());
        }
    }

    DoLog("\n---------------\n");
   // return MRES_UNIMPL;
    return MRES_OK;
}


/***********************************************************************************/
// Job Sequence Queue API
// ----------------------


//
// Dummy status fields.  In this sample code, we don't have a PLC to talk to, so we
// just simulate some of the high level status reporting
//

bool g_inJobSequenceMode = false;
bool g_jobSequenceModePaused = false;
uint32_t g_totalMoves = 0;
uint32_t g_printingMoves = 0;

/*
    The below methods are optional, for plugins which support the job sequence queue API.
    
    This allows multiple moves for a print job to be queued on the PLC itself, which can 
    help to reduce swath to swath turnaround.

    GetInterfaceVersion must set the MMI_Feature_JobSequenceQueue feature bit if the job
    sequence queue is supported.

    See MotionIntegrationHelp.chm for details.
*/
MOTION_IFTYPE eMotionResult MOTION_CALLCONV JobSequenceStart(const TMotionQueueStartArgs* apParams, const char* apAdditionalParams) {
    if (apParams->StructureSizeBytes != sizeof(TMotionQueueStartArgs)) {
        return MRES_STRUCTSIZE_MISMATCH;
    }
    //
    // apParams and apAdditionalParams are for future used and currently contain no information
    // - In the future, additional fields may be added to TMotionQueueStartArgs as required
    // - apAdditionalParams is intended as a general purpose additional command string, e.g. we may
    //   use a JSON formatted string here to set application specific parameters in the future
    //

    //
    // Here the command to put the PLC into "job sequence queue" mode must be sent.
    // Once the PLC reports it's in job sequence mode, the application will not send any standard Move_To commands
    //

    // 
    // All we can do in the sample code is check we're not currently in job sequence mode (which is an error),
    // and then switch the mode on
    //
    if (g_inJobSequenceMode) {
        return MRES_JOB_SEQ_ACTIVE;
    }
    DoLog("---MotionDLL---\nJobSequenceStart\n---------------\n");
    g_inJobSequenceMode = true;
    g_jobSequenceModePaused = false;
    g_totalMoves = 0;
    g_printingMoves = 0;
    return MRES_OK;
}

MOTION_IFTYPE eMotionResult MOTION_CALLCONV JobSequenceStop(eJobSequenceStopOption aOption) {
    //
    // aOption tells us how the application wants to initiate the stop
    
    //
    // For the sample, just turn job sequence mode off
    // Note that it is *not* an error here if job sequence mode is currently inactive, the
    // application may call JobSequenceStop multiple times during an abort sequence
    // 
    DoLog("---MotionDLL---\nJobSequenceStop\n---------------\n");
    g_inJobSequenceMode = false;
    return MRES_OK;
}

MOTION_IFTYPE eMotionResult MOTION_CALLCONV JobSequencePause() {
    if (!g_inJobSequenceMode) {
        return MRES_JOB_SEQ_INACTIVE;
    }

    DoLog("---MotionDLL---\nJobSequencePause\n---------------\n");
    //
    // At this point the PLC should be told to pause processing commands from its job queue **after any in-progress move has completed **
    // 
    g_jobSequenceModePaused = true;
    return MRES_OK;
}

MOTION_IFTYPE eMotionResult MOTION_CALLCONV JobSequenceResume() {
    if (!g_inJobSequenceMode) {
        return MRES_JOB_SEQ_INACTIVE;
    }

    DoLog("---MotionDLL---\nJobSequenceResume\n---------------\n");
    //
    // At this point the PLC should be told to resume processing commands from its job queue
    // 
    g_jobSequenceModePaused = false;
    return MRES_OK;
}

MOTION_IFTYPE eMotionResult MOTION_CALLCONV JobSequenceQueueMove(const TMotionQueueMoveArgs* apParams) {
    if (apParams->StructureSizeBytes != sizeof(TMotionQueueMoveArgs)) {
        return MRES_STRUCTSIZE_MISMATCH;
    }
    if (!g_inJobSequenceMode) {
        return MRES_JOB_SEQ_INACTIVE;
    }

    //
    // Here the details of the move must be sent to the PLC, which should be implementing a
    // queue of moves.  The new move is added to the end of the queue.
    //

    //
    // Bits are set in apParams->ControlFlags to indicate the type of move - e.g. is it X then Y,
    // X only, Y only, is it a "printing" or a "non-printing" move etc.
    //
    const bool isXMove = (apParams->ControlFlags & JobMotionQueueCmd_XAxisMove) != 0;
    const bool isPrintingMove = (apParams->ControlFlags & JobMotionQueueCmd_IsPrintingMove) != 0;
    const bool isYMove = (apParams->ControlFlags & JobMotionQueueCmd_YAxisMove) != 0;
    const bool isMoveYAfterPrintComplete = (apParams->ControlFlags & JobNotionQueueCmd_MoveYAfterPrintComplete) != 0;
    const bool isSkipWaitForY  = (apParams->ControlFlags & JobNotionQueueCmd_SkipPreviousWaitForY) != 0;
    const bool isPauseAfterMove = (apParams->ControlFlags & JobMotionQueueCmd_PauseAfterMove) != 0;
    const bool isStopAfterMove = (apParams->ControlFlags & JobMotionQueueCmd_StopAfterMove) != 0;

    DoLog("---MotionDLL---\nJobSequenceQueueMove IsX=%d IsPrintMove=%d IsY=%d isMoveYAfterPrintComplete=%d isSkipYWaitForY=%d isPause=%d isStop=%d\n---------------\n",
          isXMove, isPrintingMove, isYMove, isMoveYAfterPrintComplete, isSkipWaitForY, isPauseAfterMove, isStopAfterMove);

    //
    // For the sample, we just count the number of moves as if they had already completed
    //
    g_totalMoves++;
    if (isPrintingMove) {
        g_printingMoves++;
    }
    

    //
    // There are two important queue control flags which are part of the queued move structure.
    // These tell the job queue to (a) enter pause after the move has completed, or (b) exit job sequence mode after the move has completed.
    //
    // (a) is used for the situation where MetScan needs to carry out in-job maintenance actions (spitting, head cleaning) so must
    //     take over control again and use the standard Move_To commands
    // (b) is used at the end of a print job
    //
    // Here we just immediately move into the pause / stop state.
    // In a real implementation, this must not happen until the PLC has reached the corresponding command in its queue.
    //
    if (isPauseAfterMove) {
        g_jobSequenceModePaused = true;
    }
    if (isStopAfterMove) {
        g_inJobSequenceMode = false;
    }

    return MRES_OK;
}

MOTION_IFTYPE eMotionResult MOTION_CALLCONV GetJobSequenceStatus(TMotionQueueStatus* apParams) {
    if (apParams->StructureSizeBytes != sizeof(TMotionQueueStatus)) {
        return MRES_STRUCTSIZE_MISMATCH;
    }

    //
    // Report the current job queue status including the current positions of the X and Y axes.
    // Normally this information will come from the PLC.
    // Here we just fill in a few sample fields set in the example code above.
    // Note that it is valid for GetJobSequenceStatus to be called irrespective of whether job sequence mode
    // is currently active, for any plugin which supports the MMI_Feature_JobSequenceQueue feature.
    //
    apParams->StatusFlags = 0;
    if (g_inJobSequenceMode) {
        apParams->StatusFlags |= JobMotionQueueStatus_QueueIsEnabled;
    }
    if (g_jobSequenceModePaused) {
        apParams->StatusFlags |= JobMotionQueueStatus_QueueIsPaused;
    }
    apParams->TotalMovesQueued = g_totalMoves;
    apParams->TotalMovesCompleted = g_totalMoves;
    apParams->PrintingMovesCompleted = g_printingMoves;
    apParams->XAxisPosition = 123;
    apParams->YAxisPosition = 456;

    //
    // There are a few placeholder TMotionQueueStatus fields for possible future use if
    // we want to introduce job queue time tracking diagnostics in the PLC - e.g. to report 
    // how much time it spends in job queue mode, how much time it spends in actual movements etc.
    //
    // These fields are QueueEnabledTimeMs, QueuePausedTimeMs and QueuePrintingMoveTimeMs.
    // Currently they are ignored by MetScan so should not be used.
    // 

    return MRES_OK;
}



const char* galilGetErrorString(GReturn x)
{
    switch (x)
    {
    case G_NO_ERROR://  //!< Return value if function succeeded. 
        return G_NO_ERROR_S;

    case G_GCLIB_ERROR: //!< General library error. Indicates internal API caught an unexpected error. Contact Galil support if this error is returned, softwaresupport@galil.com.
        return G_GCLIB_ERROR_S;// "gclib unexpected error"

    case G_GCLIB_UTILITY_ERROR: //!< An invalid request value was specified to GUtility.
        return G_GCLIB_UTILITY_ERROR_S; // "invalid request value or bad arguments were specified to GUtility()"

    case G_GCLIB_UTILITY_IP_TAKEN: //!< The IP cannot be assigned because ping returned a reply. 
        return G_GCLIB_UTILITY_IP_TAKEN_S; // "ip address is already taken by a device on the network"

    case G_GCLIB_NON_BLOCKING_READ_EMPTY: //!< GMessage, GInterrupt, and GRecord can be called with a zero timeout. If there wasn't data waiting in memory, this error is returned.
        return G_GCLIB_NON_BLOCKING_READ_EMPTY_S; // "data was not waiting for a zero-timeout read"

    case G_GCLIB_POLLING_FAILED: //!< GWaitForBool out of polling trials.
        return G_GCLIB_POLLING_FAILED_S; // "exit condition not met in specified polling period"

    case G_TIMEOUT: //!< Operation timed out. Timeout is set by the --timeout option in GOpen() and can be overriden by GSetting().
        return G_TIMEOUT_S; // "device timed out"

    case G_OPEN_ERROR: //!< Device could not be opened. E.G. Serial port or PCI device already open.
        return G_OPEN_ERROR_S; // "device failed to open"

    case G_READ_ERROR: //!< Device read failed. E.G. Socket was closed by remote host. See @ref G_UTIL_GCAPS_KEEPALIVE.
        return G_READ_ERROR_S; // "device read error"

    case G_WRITE_ERROR: //!< Device write failed. E.G. Socket was closed by remote host. See @ref G_UTIL_GCAPS_KEEPALIVE.
        return G_WRITE_ERROR_S; // "device write error"

    case G_INVALID_PREPROCESSOR_OPTIONS: //!< GProgramDownload was called with a bad preprocessor directive.
        return G_INVALID_PREPROCESSOR_OPTIONS_S; // "preprocessor did not recognize options"

    case G_COMMAND_CALLED_WITH_ILLEGAL_COMMAND: //!< GCommand() was called with an illegal command, e.g. ED, DL or QD.
        return G_COMMAND_CALLED_WITH_ILLEGAL_COMMAND_S; // "illegal command passed to command call"

    case G_DATA_RECORD_ERROR: //!< Data record error, e.g. DR attempted on serial connection.
        return G_DATA_RECORD_ERROR_S; // "data record error"

    case G_UNSUPPORTED_FUNCTION: //!< Function cannot be called on this bus. E.G. GInterrupt() on serial.
        return G_UNSUPPORTED_FUNCTION_S; // "function not supported on this communication bus"

    case G_FIRMWARE_LOAD_NOT_SUPPORTED: //!< Firmware is not supported on this bus, e.g. Ethernet for the DMC-21x3 series.
        return G_FIRMWARE_LOAD_NOT_SUPPORTED_S; // "firmware cannot be loaded on this communication bus to this hardware"

    case G_ARRAY_NOT_DIMENSIONED: //!< Array operation was called on an array that was not in the controller's array table, see LA command.
        return G_ARRAY_NOT_DIMENSIONED_S; // "array not dimensioned on controller or wrong size"

    case G_CONNECTION_NOT_ESTABLISHED: //!< Function was called with no connection.
        return G_CONNECTION_NOT_ESTABLISHED_S; // "connection to hardware not established"

    case G_ILLEGAL_DATA_IN_PROGRAM: //!< Data to download not valid, e.g. \ in data.
        return G_ILLEGAL_DATA_IN_PROGRAM_S; // "illegal ASCII character in program"

    case G_UNABLE_TO_COMPRESS_PROGRAM_TO_FIT: //!< Program preprocessor could not compress the program within the user's constraints.
        return G_UNABLE_TO_COMPRESS_PROGRAM_TO_FIT_S; // "program cannot be compressed to fit on the controller"

    case G_BAD_RESPONSE_QUESTION_MARK: //!< Operation received a ?, indicating controller has a TC error.
        return G_BAD_RESPONSE_QUESTION_MARK_S; // "question mark returned by controller"

    case G_BAD_VALUE_RANGE: //!< Bad value or range, e.g. GCon *g* variable passed to function was bad.
        return G_BAD_VALUE_RANGE_S; // "value passed to function was bad or out of range"

    case G_BAD_FULL_MEMORY: //!< Not enough memory for an operation, e.g. all connections allowed for a process already taken.
        return G_BAD_FULL_MEMORY_S; // "operation could not complete because of a memory error"

    case G_BAD_LOST_DATA: //!< Lost data, e.g. GCommand() response buffer was too small for the controller's response.
        return G_BAD_LOST_DATA_S;// "data was lost due to buffer or fifo limitations"

    case G_BAD_FILE: //!< Bad file path, bad file contents, or bad write.
        return G_BAD_FILE_S; //"file was not found, contents are invalid, or write failed"

    case G_BAD_ADDRESS: //!< Bad address
        return G_BAD_ADDRESS_S; //"a bad address was specified in open"

    case G_BAD_FIRMWARE_LOAD: //!< Bad firmware upgrade
        return G_BAD_FIRMWARE_LOAD_S; //"Firmware upgrade failed"

    case G_GCAPS_OPEN_ERROR: //!< gcaps connection couldn't open. Server is not running or is not reachable.
        return G_GCAPS_OPEN_ERROR_S; //"gcaps connection could not be opened"

    case G_GCAPS_SUBSCRIPTION_ERROR: //!< GMessage(), GRecord(), GInterrupt() called on a connection without --subscribe switch.
        return G_GCAPS_SUBSCRIPTION_ERROR_S; //"function requires subscription not specified in GOpen()"
    default:
        return "this error not handled yet!"; // + code 
        break;
    }
}

bool getGalilConfig(void)
{
    bool isOpenSuccess = false;
    std::string cHW;
    std::string cIP;
    std::string caAxis;
    std::string cbAxis;
    std::string cDefaulsSpeedA;
    std::string cDefaulsSpeedB;

    std::ifstream cFile("config.txt");
    if (cFile.is_open())
    {
        DoLog("--- CONFIG.TXT OPEN SUCCESSFULL\n---------------\n");
        isOpenSuccess = true;
        std::string line;
        while (getline(cFile, line))
        {
            line.erase(std::remove_if(line.begin(), line.end(), isspace),
                line.end());
            if (line.empty() || line[0] == '#')
            {
                continue;
            }
            auto delimiterPos = line.find("=");
            auto name = line.substr(0, delimiterPos);
            auto value = line.substr(delimiterPos + 1);

            if (name._Equal("HW"))
            {
                DoLog("--- HW:%s\n---------------\n", value);
                cHW = value;
            }
            if (name._Equal("IPAddress"))
            {
                std::cout << "*IP:" << value << std::endl;
                cIP = value + " -d";
                std::string str = value + " -d";
                const char* c = str.c_str();
                sprintf_s(pMyThrInfo->gIP, "%s", c);
                DoLog("--- IP:[%s] \n---------------\n", pMyThrInfo->gIP);
            }

            if (name._Equal("LogFileName"))
            {
                std::cout << "*LogFileName:" << value << std::endl;
                std::string str = value;
                const char* cFileName = str.c_str();
                memset(pMyThrInfo->gLogFileName, 0, 256);
                sprintf_s(pMyThrInfo->gLogFileName, "%s", cFileName);
                DoLog("--- LogFileName:[%s] \n---------------\n", pMyThrInfo->gLogFileName);
                // pMyThrInfo->gLogFile(cFileName);
               //  std::ifstream gLogFile(cFileName);
              //   pMyThrInfo->gLogFile = &gLogFile;

            }

            if (name._Equal("eStopMask"))
            {
                size_t n;
                pMyThrInfo->eStopMask = std::stoi(value, &n);
                DoLog("--- eStop Mask :%s %ld\n---------------\n", value, pMyThrInfo->eStopMask);
            }

            if (name._Equal("eStopInvert"))
            {
                if (value._Equal("true"))
                    pMyThrInfo->eStopInvert = true; // std::(value, &n);
                else
                    pMyThrInfo->eStopInvert = false; // std::(value, &n);

                DoLog("--- eStop invert :%s %d\n---------------\n", value, pMyThrInfo->eStopInvert);
            }

            if (name._Equal("SpeedCoefA"))
            {
                size_t n;
                pMyThrInfo->SpeedCoefA = std::stol(value, &n);
                DoLog("--- speed coef A :%s %ld\n---------------\n", value, pMyThrInfo->SpeedCoefA);
            }

            if (name._Equal("SpeedCoefB"))
            {
                size_t n;
                pMyThrInfo->SpeedCoefB = std::stol(value, &n);
                DoLog("--- speed coef B :%s %ld\n---------------\n", value, pMyThrInfo->SpeedCoefB);
            }

            if (name._Equal("SoftLimitA_FL"))
            {
                size_t n;
                pMyThrInfo->SoftLimitA_FL = std::stol(value, &n);
                DoLog("--- soft limit FL :%s %ld\n---------------\n", value, pMyThrInfo->SoftLimitA_FL);
            }

            if (name._Equal("SoftLimitA_BL"))
            {
                size_t n;
                pMyThrInfo->SoftLimitA_BL = std::stol(value, &n);
                DoLog("--- soft limit BL :%s %ld\n---------------\n", value, pMyThrInfo->SoftLimitA_BL);
            }

            if (name._Equal("HomeSpeedA"))
            {
                size_t n;
                pMyThrInfo->HomeSpeedA = std::stod(value, &n);
                DoLog("--- home A set speed:%s %ld\n---------------\n", value, pMyThrInfo->HomeSpeedA);
            }

            if (name._Equal("HomeSpeedB"))
            {
                size_t n;
                pMyThrInfo->HomeSpeedB = std::stod(value, &n);
                DoLog("--- home B set speed:%s %ld\n---------------\n", value, pMyThrInfo->HomeSpeedB);
            }



            if (name._Equal("aAxis"))
            {
                caAxis = value;
                size_t n;
                pMyThrInfo->gaAxis = std::stod(caAxis, &n);
                DoLog("--- A Axis:%s %ld\n---------------\n", value, pMyThrInfo->gaAxis);
            }
            if (name._Equal("bAxis"))
            {
                cbAxis = value;
                size_t n;
                pMyThrInfo->gbAxis = std::stod(cbAxis, &n);
                DoLog("--- B Axis:%s %ld\n---------------\n", value, pMyThrInfo->gbAxis);
            }
            if (name._Equal("DefaultSpeedA"))
            {
                DoLog("--- ASpeed:%s\n---------------\n", value);
                cDefaulsSpeedA = value;
            }
            if (name._Equal("DefaultSpeedB"))
            {
                DoLog("--- BSpeed:%s\n---------------\n", value);
                cDefaulsSpeedB = value;
            }
        }
    }
    else
    {
        DoLog("---***Couldn't open config file for reading.***\n---------------\n");
    }
    return isOpenSuccess;
}

/***********************************************************************************/