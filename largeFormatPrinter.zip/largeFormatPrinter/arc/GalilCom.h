﻿#pragma once
#include <gclib.h>
#include <gclibo.h>

class GalilCom
{
public:

	typedef void (*call_back) (void);

	GCon g = 0;
	bool isConnect;
	char broadcastIP[32];
	bool tryToConnect(char* _ip);
	bool tryToClose();
	bool isGalilMoutionInCluster();
	void check(GReturn rc);
	int getLimitSwitcheA(void);
	int getInput0(void);
	void setBit(int bit, bool val);
	bool tryToGoHomeA(void);
	bool tryToStopA(void);
	bool tryToMoveRelA(long pos);
	bool tryToMoveAbsA(long pos);
	bool tryToSetSpeedA(long speed);
	bool tryToGetPos(double* aPs, int* aSt);
	void tryToSetLimitSwitchA(void);
	void tryToSendMessage(char* msg);
	void tryToCreateMessagessTask(void);

	call_back cb;

	/*
	
	При хоуминг казваме така:
                GalilCheck(GCmd(pMyThrInfo->ghandleCommand, "LDA=2”), pMyThrInfo->ghandleCommand); // LDA=0 =ENABLE, =1 FWRD - DISABLE, =2 BACK DISABLE, 3 DISABLE BOTH

След като се хоумне казваме така: демек след код 10 във SC
                GalilCheck(GCmd(pMyThrInfo->ghandleCommand, "LDA=0"), pMyThrInfo->ghandleCommand); // LDA=0 =ENABLE, =1 FWRD - DISABLE, =2 BACK DISABLE, 3 DISABLE BOTH

	*/

};

