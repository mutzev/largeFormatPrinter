#include "CustomLed.h"

static LRESULT CALLBACK CustomLedProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_NCCREATE:
	{
		CustomLedData* pDat = (CustomLedData*)malloc(sizeof(CustomLedData));
		if (pDat == NULL)
		{
			OutputDebugStringA("This must not never happening\n");
			exit(1);
			return FALSE;
		}

		pDat->myWnd = hWnd;
		pDat->ID = GetDlgCtrlID(hWnd);
		pDat->select = false;
		pDat->enable = true;

		SetWindowLongPtr(hWnd, 0, (LONG_PTR)pDat);
	}
	return TRUE;

	case WM_ERASEBKGND:
		return 1;
	case WM_PAINT:
	{
		CustomLedData* pData = (CustomLedData*)GetWindowLongPtr(hWnd, 0);
		if (!pData) return 0;

		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hWnd, &ps);
		RECT rect;
		GetClientRect(hWnd, &rect);

		int width = rect.right;
		int height = rect.bottom;

		HDC hdcMem = CreateCompatibleDC(ps.hdc);

		HBITMAP hbmMem = CreateCompatibleBitmap(ps.hdc, width, height);
		HGDIOBJ hOld = SelectObject(hdcMem, hbmMem);

		HBRUSH greenBrush = CreateSolidBrush(pData->select? RGB(0, 255, 0):RGB(0, 128, 0));
		HGDIOBJ oldBrush = SelectObject(hdcMem, greenBrush);
		Rectangle(hdcMem, rect.left, rect.top, rect.right, rect.bottom);
		SelectObject(hdcMem, oldBrush);
		DeleteObject(greenBrush);

		SetBkColor(hdcMem, RGB(100, 100, 255));
		SetTextColor(hdcMem, RGB(255, 255, 255));
		SetBkMode(hdcMem, TRANSPARENT);

		//DrawTextA(hdcMem, pData->caption, strlen(pData->caption), &rect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);

		BitBlt(hdc, 0, 0, width, height, hdcMem, 0, 0, SRCCOPY);

		SelectObject(hdcMem, hOld);
		DeleteObject(hbmMem);
		DeleteDC(hdcMem);

		EndPaint(hWnd, &ps);
		ReleaseDC(hWnd, hdc);
		return 0;

	}
	return 0;
	}

	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}

void CustomLedUnRegister(void)
{
	UnregisterClass(L"CustomClass", NULL);
	OutputDebugString(L"\n***custom class unregisterk***\n");
}

void CustomLedRegister(void)
{
	WNDCLASS wc = { 0 };

	wc.style = CS_GLOBALCLASS | CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc = CustomLedProc;
	//wc.hCursor = LoadCursor(NULL, IDC_HAND);
	wc.lpszClassName = L"CustomLedClass";
	wc.cbWndExtra = sizeof(CustomLedData);
	//wc.hbrBackground = GetSysColorBrush(BLACK_BRUSH); //CreateSolidBrush(RGB(200, 200, 0));
	if (RegisterClass(&wc))
	{
		OutputDebugString(L"\n***custom led class register ok***\n");
	}
	else
	{
		OutputDebugString(L"\n***custom led class register failed***\n");
	}
}


void setSelect(HWND hwnd, bool select)
{
	CustomLedData* pData = (CustomLedData*)GetWindowLongPtr(hwnd, 0);
	pData->select = select;
	InvalidateRect(hwnd, NULL, TRUE);
}

