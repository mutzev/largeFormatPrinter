#include "GalilCom.h"
#include <windows.h>
#include <stdio.h>
#include <wchar.h>
#include <string.h>
#include <iostream>
#include <cstring>
#include <thread> 

/*
MG{P2}"#S1ffffffffff0$"{S15}
# begin 
S - set, G - Get
1 - address 1 - head, 2 Print
10 x 4 bit 40 input, 40 output 
0 - CRC
$ end

PC -> SET LED1, LED2, LED1 & LED2
PC -> GET INP1, INP2....

silab -> galil "alive" small caps  
galil -> PC "ALIVE" UpperCase
silab -> tmr 10,100,1000ms
silab -> readSPIKeyborad()
silab -> readSPIInput()
silabs -> wwiteSPIOutput()
*/


typedef struct
{
	GCon ghandleMessagess;
	bool threadMessagessLoop;
	char messageBuffer[32];
	char messageIndex;
} MYTHREAD, * PMYTHREAD;

static PMYTHREAD pMyThrInfo;

GReturn message(GCon g)
{
	int b = 0, m = 0; //Reset message buffer
	char message[G_SMALL_BUFFER],buf[G_SMALL_BUFFER];
	GReturn rc;
   // Lines returned by GMessage() can be one of three types:
   // 1) Standard Lines begin with a space (" ")
   // 2) Crashed code begins with a question mark ("?")
   // 3) Trace Lines begin with a line number ("1,6,15...")

   //While still receiving messages
	rc = GMessage(g, buf, G_SMALL_BUFFER);
	if (rc == G_NO_ERROR)
	{
		OutputDebugStringA(buf);
	}
	return rc;
}

DWORD WINAPI ThreadMessageFunc(LPVOID lpParam)
{
	PMYTHREAD pData = (PMYTHREAD)lpParam;

	OutputDebugStringA("create thread messagess");

	while (pData->threadMessagessLoop)
	{
		if (!pMyThrInfo->ghandleMessagess)
		{
			OutputDebugStringA("try to create messagess socket");
			GOpen("192.168.0.2 -d --timeout 10000", &pMyThrInfo->ghandleMessagess);
			if (pMyThrInfo->ghandleMessagess)
			{
				OutputDebugStringA("messagess socket opened successfully");
			}
			else
			{
				OutputDebugStringA("messagess socket create failed!");
			}
		}
		else 
		{ 
			OutputDebugStringA("\n*** try message read ***\n");

			try
			{
				GReturn rc = message(pMyThrInfo->ghandleMessagess);
			}
			catch (GReturn gr)
			{
				OutputDebugStringA("\n***message read error***\n");
			}

			OutputDebugStringA("\n*** after try message read ***\n");


			//BYTE 1  S - SET, G - GET for begin
			// BYTE 2 ADDRESS 0-F
			// BYTE 3 AND 4 0-F BCD 8 BIT DATA
			// BYTE 5 0-9 CRC ascii mod/10
			// BYTE 6 $ FOR END
			/*
			int rc = 0, b = 0, m = 0;
			char buf[G_SMALL_BUFFER], message[G_SMALL_BUFFER]; //traffic buffer
			memset(buf, 0, G_SMALL_BUFFER);
			memset(message, 0, G_SMALL_BUFFER);

			OutputDebugStringA("before read message\n");


				while ((rc = GMessage(pMyThrInfo->ghandleMessagess, buf, G_SMALL_BUFFER)) == G_NO_ERROR)
				{
					b = 0; //reset buffer index

					while (buf[b] != '\0') //While message characters are in the buffer
					{
						message[m] = buf[b]; //Copy chars from buffer to message

						//If the message ends in "\r\n" its ready to be terminated
						if (m > 0 && message[m] == '\n' && message[m - 1] == '\r')
						{
							message[m + 1] = '\0'; //Null terminate the message

							char temp[1024];
							sprintf_s(temp, "\n *** rc [%d] [%02X][%02X][%02X][%02X][%02X][%02X][%02X][%02X][%02X][%02X][%02X][%02X]\n", rc,
								message[0],
								message[1],
								message[2],
								message[3],
								message[4],
								message[5],
								message[6],
								message[7],
								message[8],
								message[9],
								message[10],
								message[11]);
							OutputDebugStringA(temp);
							OutputDebugStringA(message);

							m = 0;  //Reset message index
						}
						else
						{
							m++; //Increment message index
						}

						b++; //Increment buf index
					}
				}
				OutputDebugStringA("after read message\n");
				*/

		}
		Sleep(1);
	}

	GReturn gc = GClose(pMyThrInfo->ghandleMessagess);

	return 0;
}


// to create task who wait for messages from galil
/*



   // If no communication has been made to gcaps for 10 minutes the connection
   // will expire. This can be prevented by periodically sending the GUtility()
   // Keep Alive command
   e(GUtility(g, G_UTIL_GCAPS_KEEPALIVE, NULL, NULL));

*/

#pragma warning(disable : 4996)

void GalilCom::tryToSendMessage(char* msg)
{
	char buf[G_SMALL_BUFFER]; //traffic buffer
	char* trimmed; //trimmed string pointer
	char temp[1024];
	sprintf_s(temp, "MG{P2}\"%s\"{S%zd}", msg,strlen(msg));
	OutputDebugStringA(temp);
	GCmdT(g, temp, buf, sizeof(buf), &trimmed);

	return;
}

bool GalilCom::tryToGetPos(double* aPs, int* aSt)
{
	check(GCmdD(g, "RP A", aPs));
	check(GCmdI(g, "SC A", aSt));

	return true;
}

int GalilCom::getInput0(void)
{
	int TI0 = 0;
	check(GCmdI(g, "TI0", &TI0));
	return TI0; //(FLS << 2) | (BLS << 1) | HLS;
}

int GalilCom::getLimitSwitcheA(void)
{
	int switchStatusA = 0;
	check(GCmdI(g, "TS A", &switchStatusA));

	bool FLS, BLS, HLS;
	FLS = (switchStatusA & 8);
	BLS = (switchStatusA & 4);
	HLS = (switchStatusA & 2);

	return switchStatusA; // (FLS << 2) | (BLS << 1) | HLS;
}

void GalilCom::check(GReturn rc)
{
	if (rc != G_NO_ERROR)
	{
		char str[256];
		sprintf_s(str, "\n!!!panic!!!\nG Check error: %d \n", rc);
		//OutputDebugStringA(str);

		//cb();

		switch (rc)
		{
		case G_BAD_RESPONSE_QUESTION_MARK:
		{
			char logBuffer[1024];
			char buf[G_SMALL_BUFFER]; //traffic buffer
			char* trimmed; //trimmed string pointer

			GReturn x = GCmdT(g, "TC1", buf, sizeof(buf), &trimmed);
			sprintf_s(logBuffer, ">>> TC1: [%d] [%s] <<<\n", x, trimmed);
			OutputDebugStringA(logBuffer);
			//callback(h);
		}
		break;
		}
	}
	else
	{

	}
}

bool GalilCom::tryToClose()
{
	GReturn rc = 0;
	if (g)
		rc = GClose(g);
	isConnect = false;
	return (rc == G_NO_ERROR);
}

void GalilCom::setBit(int bit, bool val)
{
	char xbit[32];
	memset(xbit, 0, 32);
	sprintf(xbit,"%s%d",val?"SB":"CB",bit);
	OutputDebugStringA(xbit);
	OutputDebugStringA("\n\n\n\n");
	check(GCmd(g, xbit));
}

bool GalilCom::tryToSetSpeedA(long speed)
{
	char buf[128];
	sprintf_s(buf, "SP %ld", speed);
	check(GCmd(g, buf));
	return true;
}

bool GalilCom::tryToMoveRelA(long pos)
{
	char buf[128];
	check(GCmd(g, "SH A"));
	sprintf_s(buf, "PR %ld",pos);
	check(GCmd(g, buf));
	check(GCmd(g, "BG A"));
	return true;
}

bool GalilCom::tryToMoveAbsA(long pos)
{
	char buf[128];
	check(GCmd(g, "SH A"));
	sprintf_s(buf, "PA %ld", pos);
	check(GCmd(g, buf));
	check(GCmd(g, "BG A"));
	return true;
}

bool GalilCom::tryToStopA(void)
{
	check(GCmd(g, "ST A"));
	return true;
}

void GalilCom::tryToSetLimitSwitchA(void)
{
	char buf[256];

	check(GCmd(g, "LDA=0")); // LDA=0 =ENABLE, =1 FWRD - DISABLE, =2 BACK DISABLE, 3 DISABLE BOTH

	memset(buf, 0, 256);
	sprintf_s(buf, "FL %ld", 0);
	check(GCmd(g, buf));

	memset(buf, 0, 256);
	sprintf_s(buf, "BL %ld", 10000);
	check(GCmd(g, buf));

	memset(buf, 0, 256);
	sprintf_s(buf, "SP %ld", 10000);
	check(GCmd(g, buf));
}

bool GalilCom::tryToGoHomeA(void)
{
	char buf[128];
	check(GCmd(g, "LDA=2")); // LDA=0 =ENABLE, =1 FWRD - DISABLE, =2 BACK DISABLE, 3 DISABLE BOTH

	check(GCmd(g, "FL 2147483647"));
	check(GCmd(g, "BL -2147483647"));
	// HV - home velocity
	sprintf_s(buf, "SP %ld", (long)2000 );
	check(GCmd(g, buf));

	check(GCmd(g, "SH A"));
	check(GCmd(g, "HM A"));
	check(GCmd(g, "BG A"));
	return true;
}

void GalilCom::tryToCreateMessagessTask(void)
{
	pMyThrInfo = (PMYTHREAD)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, sizeof(MYTHREAD));
	pMyThrInfo->threadMessagessLoop = true;
	HANDLE thread = CreateThread(NULL, 0, ThreadMessageFunc, pMyThrInfo, 0, NULL);
}

bool GalilCom::tryToConnect(char* _ip)
{
	if (_ip == NULL)
	{
		OutputDebugStringA("no valid ip...\n");
		return false;
	}
		OutputDebugStringA("try to connect galil...\n");
		GReturn rc = GOpen(_ip, &g); //Open a connection to Galil, store the identifier in g.
		if (rc == G_NO_ERROR)
		{
			char xyz[1024];
			check(GInfo(g, xyz, sizeof(xyz))); //grab connection string
			isConnect = true;
			memset(broadcastIP, 0, 32);
			memcpy(broadcastIP, _ip, strlen(_ip));
			OutputDebugStringA("connect success...\n");
			//tryToCreateMessagessTask();
			return true;
		}
		else
		{
			OutputDebugStringA("connect failed...\n");
			isConnect = false;
			return false;
		}

}

bool GalilCom::isGalilMoutionInCluster()
{
	char buf[128];
	GAddresses(buf, sizeof(buf)); //list available addresses
	if (strlen(buf) > 0) // com1
	{
		return true;
	}
	return false;
}
