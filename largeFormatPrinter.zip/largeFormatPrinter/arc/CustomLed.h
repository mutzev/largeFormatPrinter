#include <windows.h>
#include <stdio.h>
#include <wchar.h>
#include <string>
#include <iostream>
#include <stdlib.h>
#include <windowsx.h>
#include <commctrl.h>
#include <stdlib.h>
#include <tchar.h>
#include <strsafe.h>

#pragma once

#pragma warning(disable : 4996)

#pragma pack(1)
#pragma comment(lib,"msimg32.lib")

typedef struct {
	HWND myWnd;
	char caption[128];
	int ID;
	bool select;
	bool enable;
} CustomLedData;

static LRESULT CALLBACK CustomLedProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
void CustomLedRegister(void);
void CustomLedUnRegister(void);
void setSelect(HWND hwnd, bool select);
