#include <windows.h>
#include <commctrl.h>
#include <wchar.h>
#include <gclib.h>
#include <gclibo.h>
#include "resource.h"
#include "CustomButton.h"
#include "GalilCom.h"
#include "CustomLed.h"

#pragma pack(1)

GalilCom gc;

LRESULT CALLBACK PanelProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK dlgPrintProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK dlgHeadProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK dlgOperatorProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

HINSTANCE g_hinst;
// LRESULT g_pos = 150;

#pragma comment(lib, "comctl32.lib")

static HWND mainWnd,dlgHead, dlgOperator, dlgPrint, hwndParent,hwndStatus;

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE PrevInstance, LPSTR CmdLine, int CmdShow)
{
    MSG  msg;
    WNDCLASSEX wc = { 0 };

    g_hinst = hInstance;

    wc.lpszClassName = L"ServiceTool";
    wc.hInstance = hInstance;
    wc.hbrBackground = GetSysColorBrush(COLOR_3DFACE);
    wc.lpfnWndProc = WndProc;
    wc.hCursor = LoadCursor(0, IDC_ARROW);

    wc.style = CS_OWNDC | CS_VREDRAW | CS_HREDRAW | CS_DBLCLKS;
    wc.cbSize = sizeof(WNDCLASSEX);
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;

    HWND hwndTrack, hwndBurn, hwndButton;
    WNDCLASSW rwc = { 0 };

    INITCOMMONCONTROLSEX InitCtrlEx;

    InitCtrlEx.dwSize = sizeof(INITCOMMONCONTROLSEX);
    InitCtrlEx.dwICC = ICC_BAR_CLASSES;
    InitCommonControlsEx(&InitCtrlEx);

    CustomRegister();
    CustomLedRegister();

    RegisterClassEx(&wc);

    mainWnd = CreateWindowEx(WS_EX_CLIENTEDGE, L"ServiceTool", L"Service Tool", WS_OVERLAPPEDWINDOW|WS_POPUP|WS_CAPTION|WS_SYSMENU, CW_USEDEFAULT, CW_USEDEFAULT, 1280, 900, HWND_DESKTOP, NULL, hInstance, NULL);
    ShowWindow(mainWnd, SW_SHOW);

     dlgHead = CreateDialog(g_hinst, MAKEINTRESOURCE(IDD_HEAD), mainWnd, dlgHeadProc, 0);
     dlgOperator = CreateDialog(g_hinst, MAKEINTRESOURCE(IDD_OPERATOR), mainWnd, dlgOperatorProc, 0);
     dlgPrint = CreateDialog(g_hinst, MAKEINTRESOURCE(IDD_PRINT), mainWnd, dlgPrintProc, 0);

     HWND b1 = CreateWindow(
         L"BUTTON",  // Predefined class; Unicode assumed 
         L"PRINT",      // Button text 
         WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,  // Styles 
         10,         // x position 
         10,         // y position 
         100,        // Button width
         100,        // Button height
         mainWnd,     // Parent window
         (HMENU)IDC_PRINT,       // No menu.
         (HINSTANCE)GetWindowLongPtr(mainWnd, GWLP_HINSTANCE),
         NULL);      // Pointer not needed.

     HWND b2 = CreateWindow(
         L"BUTTON",  // Predefined class; Unicode assumed 
         L"HEAD",      // Button text 
         WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,  // Styles 
         10,         // x position 
         120,         // y position 
         100,        // Button width
         100,        // Button height
         mainWnd,     // Parent window
         (HMENU)IDC_HEAD,       // No menu.
         (HINSTANCE)GetWindowLongPtr(mainWnd, GWLP_HINSTANCE),
         NULL);      // Pointer not needed.
     
     HWND b3 = CreateWindow(
         L"BUTTON",  // Predefined class; Unicode assumed 
         L"OPERATOR",      // Button text 
         WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,  // Styles 
         10,         // x position 
         230,         // y position 
         100,        // Button width
         100,        // Button height
         mainWnd,     // Parent window
         (HMENU)IDC_OPERATOR,       // No menu.
         (HINSTANCE)GetWindowLongPtr(mainWnd, GWLP_HINSTANCE),
         NULL);      // Pointer not needed.

     while (GetMessage(&msg, NULL, 0, 0)) {
            if (!IsDialogMessage(dlgHead, &msg) &&
                !IsDialogMessage(mainWnd, &msg) &&
                !IsDialogMessage(dlgPrint, &msg) &&
                !IsDialogMessage(dlgOperator, &msg))
            {
                TranslateMessage(&msg);
                DispatchMessage(&msg);
            }
     }

    CustomUnRegister();
    CustomLedUnRegister();

    return (int)msg.wParam;
}

LRESULT CALLBACK dlgPrintProc(HWND hwnd, UINT msg,
    WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {
    case WM_CTLCOLORSTATIC:
        if ((HWND)lParam == GetDlgItem(hwnd, 2001))
        {
            SetTextColor((HDC)wParam, RGB(0, 255, 0));
        }
        else
        {
            SetTextColor((HDC)wParam, RGB(0, 128, 0));
        }
        SetBkMode((HDC)wParam, TRANSPARENT);
        return (BOOL)CreateSolidBrush(GetSysColor(COLOR_MENU));
    case WM_COMMAND:
        switch (wParam)
        {
        case ID_SELECT_ALL:
            break;
        case ID_DESELECT_ALL:
            break;
        case ID_DO_BOOM:
            break;
        }
        break;
    default:
        return false;
    }
    return true;
}

void doBoom(HWND hwnd)
{
    static int headOutput[] = { 2018,2019,2020,2021,2022,2023,2024,2025,2026,2027,2028,2029,2030,2031,2032 };
    int i;
    for (i = 0; i < sizeof(headOutput); i++)
    {
    // prepare string to setting
    }
    gc.tryToSendMessage((char *)"#S1ffffffffff0$");
}

void setHeadOutputs(HWND hwnd, bool b)
{
    static int headOutput[] = { 2018,2019,2020,2021,2022,2023,2024,2025,2026,2027,2028,2029,2030,2031,2032 };
    int i;
    for (i = 0; i < sizeof(headOutput); i++)
    {
        SendMessage(GetDlgItem(hwnd, headOutput[i]), BM_SETCHECK, b? BST_CHECKED:BST_UNCHECKED, 0);
    }
}

LRESULT CALLBACK dlgHeadProc(HWND hwnd, UINT msg,
    WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {

    case WM_CTLCOLORSTATIC:
        if ((HWND)lParam == GetDlgItem(hwnd, 2005))
        {
            SetTextColor((HDC)wParam, RGB(0, 255, 0));
        }
        else
        {
            SetTextColor((HDC)wParam, RGB(0, 128, 0));
        }
            SetBkMode((HDC)wParam, TRANSPARENT);
            return (BOOL)CreateSolidBrush(GetSysColor(COLOR_MENU));
    case WM_COMMAND:
        switch (wParam)
        {
        case ID_SELECT_ALL:
            setHeadOutputs(hwnd, true);
            break;
        case ID_DESELECT_ALL:
            setHeadOutputs(hwnd, false);
            break;
        case ID_DO_BOOM:
            doBoom(hwnd);
            break;
        }
        break;
    default:
        return false;
    }
    return true;
}

LRESULT CALLBACK dlgOperatorProc(HWND hwnd, UINT msg,
    WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {
    case WM_CTLCOLORSTATIC:
        if ((HWND)lParam == GetDlgItem(hwnd, 2003))
        {
            SetTextColor((HDC)wParam, RGB(0, 255, 0));
        }
        else if ((HWND)lParam == GetDlgItem(hwnd, 2005))
        {
            SetTextColor((HDC)wParam, RGB(255, 0, 0));
        }
        else
        {
            SetTextColor((HDC)wParam, RGB(0, 128, 0));
        }
        SetBkMode((HDC)wParam, TRANSPARENT);
        return (BOOL)CreateSolidBrush(GetSysColor(COLOR_MENU));
    case WM_COMMAND:
        switch (wParam)
        {
        case ID_SELECT_ALL:
            break;
        case ID_DESELECT_ALL:
            break;
        case ID_DO_BOOM:
            break;
        }
        break;
    default:
        return false;
    }
    return true;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg,
    WPARAM wParam, LPARAM lParam)
{
    static HBRUSH dlgBrush;

    switch (msg)
    {
    case WM_CTLCOLORSTATIC:
        if ((HWND)lParam == GetDlgItem(hwnd, IDC_STATUS))
        {
            SetBkMode((HDC)wParam, TRANSPARENT);
            if(gc.isConnect)
                SetTextColor((HDC)wParam, RGB(0, 255, 0));
            else
                SetTextColor((HDC)wParam, RGB(255, 0, 0));
            return (BOOL)CreateSolidBrush(GetSysColor(COLOR_MENU));
        }
        return TRUE;

    case WM_CREATE:
    {        
        //hwndStatus = CreateStatusWindowA(WS_CHILD | WS_VISIBLE | SBARS_SIZEGRIP, "sdfgsdfg", mainWnd, 4987);

        hwndStatus = CreateWindowEx(0,STATUSCLASSNAME,NULL,WS_CHILD|WS_VISIBLE|SBARS_SIZEGRIP,0,0,0,0,hwnd,(HMENU)4987,g_hinst,NULL);
        SetTimer(hwnd, 9999, 1000, NULL);
        dlgBrush = CreateSolidBrush(RGB(50, 150, 255));

        int iStatusWidths[] = { 300 };
        char text[256];
        SendMessage(hwndStatus, SB_SETPARTS, 1, (LPARAM)iStatusWidths);
        SendMessageA(hwndStatus, SB_SETTEXT, 0, (LPARAM)"12345");
       
        ShowWindow(hwndStatus, SW_SHOW);

        OutputDebugStringA("timer interrupt\n");
    }
    return true;
    case WM_CTLCOLORDLG:
        return (INT_PTR)(dlgBrush);
    case WM_CLOSE:
        DeleteObject(dlgBrush);
        DestroyWindow(hwnd);
        if (gc.isConnect)
        {
            gc.tryToClose();
        }
        return TRUE;
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    case WM_COMMAND:
        switch (wParam)
        {
        case IDC_HEAD:
            ShowWindow(dlgOperator, SW_HIDE);
            ShowWindow(dlgPrint, SW_HIDE);
            if(IsWindowVisible(dlgHead))
                ShowWindow(dlgHead, SW_HIDE);
            else
                ShowWindow(dlgHead, SW_SHOW);
            break;
        case IDC_PRINT:
            ShowWindow(dlgOperator, SW_HIDE);
            ShowWindow(dlgHead, SW_HIDE);
            if (IsWindowVisible(dlgPrint))
                ShowWindow(dlgPrint, SW_HIDE);
            else
                ShowWindow(dlgPrint, SW_SHOW);
            break;
        case IDC_OPERATOR:
            ShowWindow(dlgHead, SW_HIDE);
            ShowWindow(dlgPrint, SW_HIDE);
            if (IsWindowVisible(dlgOperator))
                ShowWindow(dlgOperator, SW_HIDE);
            else
                ShowWindow(dlgOperator, SW_SHOW);
            break;
        }
        break;
    case WM_TIMER:
        if (!gc.isConnect)
        {
            bool b = gc.tryToConnect((char*)"192.168.0.2 -d --timeout 5000");
            if (b)
            {
                gc.tryToCreateMessagessTask();
            }
        }
        if (gc.isConnect)
        {
            SetDlgItemTextA(hwnd, IDC_STATUS, "Gallic connect success.");
        }
        else
        {
            SetDlgItemTextA(hwnd, IDC_STATUS, "Try to connect galil...");
        }
        break;
    }

    return DefWindowProcW(hwnd, msg, wParam, lParam);
}

 




