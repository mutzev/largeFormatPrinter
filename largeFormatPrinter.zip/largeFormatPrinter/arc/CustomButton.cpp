#include "CustomButton.h"

void initWithTypeAndShapeAndTitle(CustomData* p, CustomType type, CustomShape shape, char *title)
{
	if (p)
	{
		p->type = type;
		p->shape = shape;
		memset(p->caption, 0, 128);
		memcpy(p->caption, title, strlen(title));
	}
}

void setCustomStatus(HWND hwnd, CustomInputStatus status)
{
	CustomData* pData = (CustomData*)GetWindowLongPtr(hwnd, 0);
	if (pData)
	{
		pData->status = status;
	}
}

void xgetCapton(HWND hWnd)
{
	WCHAR caption[255];
	int x = GetWindowTextW(hWnd, caption, 255);
}

static LRESULT CALLBACK CustomProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_ERASEBKGND:
		return 1;

	case WM_NCCREATE:
	{
		CustomData* pDat = (CustomData*)malloc(sizeof(CustomData));
		if (pDat == NULL)
		{
			OutputDebugStringA("This must not never happening\n");
			exit(1);
			return FALSE;
		}

		pDat->myWnd = hWnd;
		pDat->ID = GetDlgCtrlID(hWnd);
		pDat->LB = 0;
		pDat->onFocus = 0;
		pDat->select = false;
		pDat->shape = CUSTOM_SHAPE_ROUND;
		pDat->type = CUSTOM_TYPE_INPUT;
		pDat->enable = true;

		SetWindowLongPtr(hWnd, 0, (LONG_PTR)pDat);
		
		//xgetCapton(hWnd);

	}
	return TRUE;
	case WM_SETFOCUS:
	{
		CustomData* tmp = (CustomData*)GetWindowLongPtr(hWnd, 0);
		if (tmp == NULL) return 0;
		tmp->onFocus = TRUE;
		InvalidateRect(hWnd, NULL, TRUE);
	}
	return 0;
	case WM_KILLFOCUS:
	{
		CustomData* tmp = (CustomData*)GetWindowLongPtr(hWnd, 0);
		if (tmp == NULL) return 0;
		tmp->onFocus = FALSE;
		InvalidateRect(hWnd, NULL, TRUE);
	}
	return 0;
	case WM_MOUSEMOVE:
	{
		TRACKMOUSEEVENT tme;
		tme.cbSize = sizeof(tme);
		tme.dwFlags = TME_LEAVE;
		tme.hwndTrack = hWnd;
		TrackMouseEvent(&tme);
		CustomData* tmp = (CustomData*)GetWindowLongPtr(hWnd, 0);
		if (tmp == NULL) return 0;
		tmp->onFocus = TRUE;
		SetFocus(hWnd);
		InvalidateRect(hWnd, NULL, TRUE);
	}
	return 0;
	case WM_MOUSELEAVE:
	{
		CustomData* tmp = (CustomData*)GetWindowLongPtr(hWnd, 0);
		if (tmp == NULL) return 0;
		tmp->LB = FALSE;
		tmp->onFocus = FALSE;
		InvalidateRect(hWnd, NULL, TRUE);
	}
	return 0;
	case WM_LBUTTONDOWN:
	{
		CustomData* tmp = (CustomData*)GetWindowLongPtr(hWnd, 0);
		if (tmp == NULL) return 0;
		if (!tmp->enable) return 0;
		tmp->LB = true;
		tmp->select ^= 1;
		InvalidateRect(hWnd, NULL, TRUE);
		SetFocus(hWnd);
		SendMessage(GetParent(hWnd), WM_USER+1, tmp->ID, lParam);
	}
	return 0;
	case WM_LBUTTONUP:
	{
		CustomData* tmp = (CustomData*)GetWindowLongPtr(hWnd, 0);
		if (tmp == NULL) return 0;
		tmp->LB = FALSE;
		InvalidateRect(hWnd, NULL, TRUE);
	}
	return 0;
	case WM_PAINT:
	{
		CustomData* pData = (CustomData*)GetWindowLongPtr(hWnd, 0);
		if (!pData) return 0;
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hWnd, &ps);
		RECT rect;
		GetClientRect(hWnd, &rect);

		int width = rect.right;
		int height = rect.bottom;

		HDC hdcMem = CreateCompatibleDC(ps.hdc);

		HBITMAP hbmMem = CreateCompatibleBitmap(ps.hdc, width, height);
		HGDIOBJ hOld = SelectObject(hdcMem, hbmMem);

		HBRUSH redBrush = CreateSolidBrush(pData->select? RGB(255, 0, 0):RGB(128, 0, 0));
		HGDIOBJ oldBrush = SelectObject(hdcMem, redBrush);
		Rectangle(hdcMem, rect.left, rect.top, rect.right, rect.bottom);
		SelectObject(hdcMem, oldBrush);
		DeleteObject(redBrush);

		if (pData->select)
		{
			DrawEdge(hdcMem, &rect, EDGE_SUNKEN, BF_RECT);
		}
		else
		{
			DrawEdge(hdcMem, &rect, EDGE_RAISED, BF_RECT);
		}

		SetBkColor(hdcMem, RGB(100, 100, 255));
		SetTextColor(hdcMem, RGB(255, 255, 255));
		SetBkMode(hdcMem, TRANSPARENT);

		DrawTextA(hdcMem, pData->caption, strlen(pData->caption), &rect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);

		BitBlt(hdc, 0, 0, width, height, hdcMem, 0, 0, SRCCOPY);

		// Free-up the off-screen DC
		SelectObject(hdcMem, hOld);
		DeleteObject(hbmMem);
		DeleteDC(hdcMem);

		EndPaint(hWnd, &ps);
		ReleaseDC(hWnd, hdc);
		return 0;

	}
	return 0;
	}

	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}

void CustomUnRegister(void)
{
	UnregisterClass(L"CustomClass", NULL);
	OutputDebugString(L"\n***custom class unregisterk***\n");
}

void CustomRegister(void)
{
	WNDCLASS wc = { 0 };

	wc.style = CS_GLOBALCLASS | CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc = CustomProc;
	wc.hCursor = LoadCursor(NULL, IDC_HAND);
	wc.lpszClassName = L"CustomClass";
	wc.cbWndExtra = sizeof(CustomData); 
	wc.hbrBackground = GetSysColorBrush(BLACK_BRUSH); //CreateSolidBrush(RGB(200, 200, 0));
	if (RegisterClass(&wc))
	{
		OutputDebugString(L"\n***custom class register ok***\n");
	} 
	else
	{
		OutputDebugString(L"\n***custom class register failed***\n");
	}
}
