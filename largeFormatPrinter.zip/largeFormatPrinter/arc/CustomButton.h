#include <windows.h>
#include <stdio.h>
#include <wchar.h>
#include <string>
#include <iostream>
#include <stdlib.h>
#include <windowsx.h>
#include <commctrl.h>
#include <stdlib.h>
#include <tchar.h>
#include <strsafe.h>

#pragma once

#pragma warning(disable : 4996)

#pragma pack(1)
#pragma comment(lib,"msimg32.lib")

//HWND GW;

enum CustomShape
{
	CUSTOM_SHAPE_BOX=0, CUSTOM_SHAPE_ROUND=1, CUSTOM_SHAPE_CIRCLE=2, CUSTOM_SHAPE_POLY=3
};

enum CustomType
{
	CUSTOM_TYPE_INPUT=0, CUSTOM_TYPE_OUTPUT=1
};

enum CustomInputStatus
{
	CUSTOM_INPUT_ACTIVE = 1,
	CUSTOM_INPUT_INACTIVE = 2
};

typedef struct {
	HWND myWnd;
	bool onFocus;
	bool LB;
	CustomType type;
	CustomShape shape;
	CustomInputStatus status;
	char caption[128];
	int cnt;
	int ID;
	bool select;
	bool enable;
} CustomData;

//HCURSOR hCur1, hCur2;

static LRESULT CALLBACK CustomProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
void CustomRegister(void);
void CustomUnRegister(void);
void initWithTypeAndShapeAndTitle(CustomData* p, CustomType type, CustomShape shape, char* title);
void setCustomStatus(HWND hwnd, CustomInputStatus status);