//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by GalilUtility.rc
//
#define IDC_MYICON                      2
#define IDD_UTILITY                     101
#define IDD_GALILUTILITY_DIALOG         102
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDS_STRING104                   104
#define IDM_EXIT                        105
#define IDS_STRING105                   105
#define IDI_GALILUTILITY                107
#define IDI_SMALL                       108
#define IDC_GALILIP                     109
#define IDC_GALIL_STAT                  109
#define IDR_MAINFRAME                   128
#define IDD_PRINT                       129
#define IDD_OPERATOR                    130
#define IDD_HEAD                        131
#define IDC_LIST_IP_ADDRESS             1000
#define IDC_BUTTON1                     1002
#define IDC_MOVE_A                      1002
#define IDC_BUTTON2                     1003
#define IDC_GO_HOME_A                   1003
#define IDC_BUTTON3                     1004
#define IDC_STOP_A                      1004
#define IDC_BUTTON4                     1005
#define IDC_SET_SPEED_A                 1005
#define IDC_BUTTON5                     1006
#define IDC_MOVE_B                      1006
#define IDC_BUTTON6                     1007
#define IDC_GO_HOME_B                   1007
#define IDC_BUTTON7                     1008
#define IDC_STOP_B                      1008
#define IDC_PRINT                       1008
#define IDC_BUTTON8                     1009
#define IDC_SET_SPEED_B                 1009
#define IDC_CONNECT                     1010
#define IDC_OUT1                        1011
#define IDC_OUT2                        1012
#define IDC_OUT3                        1013
#define IDC_PRINT2                      1013
#define IDC_OPERATOR                    1013
#define IDC_OUT4                        1014
#define IDC_HEAD                        1014
#define IDC_OUT5                        1015
#define IDC_OUT6                        1016
#define IDC_OUT7                        1017
#define IDC_OUT8                        1018
#define IDC_ACTION                      1021
#define IDC_EDIT1                       1023
#define IDC_MOVE_B2                     1024
#define IDC_MOVE_A2                     1025
#define IDC_EDIT2                       1026
#define IDC_EDIT3                       1028
#define IDC_EDIT4                       1029
#define IDC_EDIT5                       1030
#define IDC_EDIT6                       1031
#define IDC_BUTTON9                     1035
#define IDC_MANUAL_CONNECT              1035
#define IDC_BUTTON10                    1036
#define IDC_CUSTOM5                     1037
#define IDC_BUTTON11                    1037
#define IDC_BUTTON12                    1038
#define IDC_IPADDRESS                   1044
#define IDC_DLGPARENT                   1051
#define IDC_CHECK1                      1052
#define IDC_CHECK2                      1053
#define IDC_CHECK3                      1054


#define IDI_CYAN_LOW					2000
#define IDI_CYAN_HIGH					2001
#define IDI_MAGENTA_LOW					2002
#define IDI_MAGENTA_HIGH 				2003
#define IDI_YELLOW_LOW					2004
#define IDI_YELLOW_HIGH					2005
#define IDI_BLACK_LOW					2006
#define IDI_BLACK_HIGH					2007
#define IDI_VACUUM_TANK_LEVEL			2008
#define IDI_CARIEGE_OUT1				2009
#define IDI_CARIEGE_OUT2				2010
#define IDI_VACUUM_SENSOR				2011
#define IDI_SPARE_I1					2012
#define IDI_SPARE_I2					2013
#define IDI_SPARE_I3					2014
#define IDI_SPARE_I4					2015
#define IDI_SPARE_I5					2016
#define IDI_SPARE_I6					2017

#define IDO_SOLVENT_MAGENTA				2018
#define IDO_SOLVENT_CYAN				2019
#define IDO_SOLVENT_YELLOW				2020
#define IDO_SOLVENT_BLACK				2021
#define IDO_VACUUM_MAGENTA				2022
#define IDO_VACUUM_CYAN					2023
#define IDO_VACUUM_YELLOW				2024
#define IDO_VACUUM_BLACK				2025
#define IDO_SOLVENT_VALVE				2026
#define IDO_SPARE_OU1					2027
#define IDO_SPARE_OU2					2028
#define IDO_SPARE_OU3					2029
#define IDO_SPARE_OU4					2030
#define IDO_SPARE_OU5					2031
#define IDO_SPARE_OU6					2032

#define ID_SELECT_ALL					2033
#define ID_DESELECT_ALL					2034
#define ID_DO_BOOM						2035


#define IDC_STATIC                      -1
#define IDC_STATUS                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1054
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
