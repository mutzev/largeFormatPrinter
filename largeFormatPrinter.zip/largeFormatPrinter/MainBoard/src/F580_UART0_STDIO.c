
#include <SI_C8051F580_Register_Enums.h>         // SFR declarations
#include <stdio.h>

#define SYSCLK      24000000           // SYSCLK frequency in Hz
#define BAUDRATE      115200           // Baud rate of UART in bps

void SYSCLK_Init (void);
void UART0_Init (void);
void PORT_Init (void);

/*
void PORT_Init (void)
{
   uint8_t SFRPAGE_save = SFRPAGE;
   SFRPAGE = CONFIG_PAGE;

   P0MDOUT |= 0x10;                    // Enable UTX as push-pull output
   XBR0 = 0x01;                        // Enable UART on P0.4(TX) and P0.5(RX)
   XBR2 = 0x40;                        // Enable crossbar and weak pull-ups

   SFRPAGE = SFRPAGE_save;
}

void SYSCLK_Init (void)
{
   uint8_t SFRPAGE_save = SFRPAGE;
   SFRPAGE = CONFIG_PAGE;

   OSCICN |= 0x87;                     // Configure internal oscillator for
                                       // its maximum frequency
   RSTSRC = 0x04;                      // Enable missing clock detector

   SFRPAGE = SFRPAGE_save;
}

void UART0_Init (void)
{
   uint8_t SFRPAGE_save = SFRPAGE;
   SFRPAGE = CONFIG_PAGE;
   SBRL0 = -104;
   SBCON0 = 0x43;
   SFRPAGE = ACTIVE1_PAGE;
   SCON0 = 0x10;                       // SCON0: 8-bit variable bit rate
   SCON0_TI = 1;                       // Indicate TX0 ready
   SFRPAGE   = ACTIVE2_PAGE;
   SCON1     = 0x50;

   SFRPAGE = SFRPAGE_save;
}
*/

void PCA0_Init()
{
    PCA0CN    = 0x40;
    PCA0MD    &= ~0x40;
    PCA0MD    = 0x0C;
    PCA0CPM0  = 0x42;
    PCA0CPM1  = 0x42;
    PCA0CPM2  = 0x42;
    SFRPAGE   = CONFIG_PAGE;
    PCA0PWM   = 0x02;
    SFRPAGE   = ACTIVE1_PAGE;
    SFRPAGE   = CONFIG_PAGE;
    PCA0PWM   |= 0x80;           // ARSEL = 1
    SFRPAGE   = ACTIVE1_PAGE;
    PCA0CPL0  = 0xF5;
    PCA0CPH0  = 0x03;
    PCA0CPL1  = 0xF5;
    PCA0CPH1  = 0x03;
    PCA0CPL2  = 0xF5;
    PCA0CPH2  = 0x03;
    SFRPAGE   = CONFIG_PAGE;
    PCA0PWM   &= ~0x80;          // ARSEL = 0
    SFRPAGE   = ACTIVE1_PAGE;
    PCA0CPL3  = 0xF5;
    PCA0CPH3  = 0x03;
}

void Timer_Init()
{
    TMOD      = 0x20;
    CKCON     = 0x08;
    TH1       = 0x98;
    SFRPAGE   = ACTIVE2_PAGE;
    TMR5CF    = 0x0A;
    TMR5CAPL  = 0x40;
    TMR5CAPH  = 0xA2;
    SFRPAGE   = ACTIVE1_PAGE;
}

void UART_Init()
{
    SCON0     = 0x10;
    SFRPAGE   = CONFIG_PAGE;
    SBRLL0    = 0x98;
    SBRLH0    = 0xFF;
    SBCON0    = 0x43;
    SFRPAGE   = ACTIVE2_PAGE;
    SCON1     = 0x50;
    SFRPAGE   = ACTIVE1_PAGE;
}

void SPI_Init()
{
    SPI0CFG   = 0x40;
    SPI0CN    = 0x0D;
    SPI0CKR   = 0x0B;
}

void ADC_Init()
{
    ADC0MX    = 0x10;
    ADC0CF    = 0xFE;
}

void Voltage_Reference_Init()
{
    REF0CN    = 0x25;
}

void Port_IO_Init()
{
    // P0.0  -  Skipped,     Push-Pull,  Digital
    // P0.1  -  Skipped,     Push-Pull,  Digital
    // P0.2  -  Skipped,     Open-Drain, Digital
    // P0.3  -  Skipped,     Open-Drain, Digital
    // P0.4  -  UART_TX (UART0), Push-Pull,  Digital
    // P0.5  -  UART_RX (UART0), Open-Drain, Digital
    // P0.6  -  Skipped,     Push-Pull,  Digital
    // P0.7  -  Skipped,     Push-Pull,  Digital

    // P1.0  -  SCK  (SPI0), Push-Pull,  Digital
    // P1.1  -  MISO (SPI0), Open-Drain, Digital
    // P1.2  -  MOSI (SPI0), Push-Pull,  Digital
    // P1.3  -  NSS  (SPI0), Push-Pull,  Digital
    // P1.4  -  Skipped,     Push-Pull,  Digital
    // P1.5  -  CEX0 (PCA0), Push-Pull,  Digital
    // P1.6  -  CEX1 (PCA0), Push-Pull,  Digital
    // P1.7  -  CEX2 (PCA0), Push-Pull,  Digital

    // P2.0  -  UART_TX (UART1), Push-Pull,  Digital
    // P2.1  -  UART_RX (UART1), Open-Drain, Digital
    // P2.2  -  Unassigned,  Open-Drain, Digital
    // P2.3  -  Unassigned,  Open-Drain, Digital
    // P2.4  -  Unassigned,  Push-Pull,  Digital
    // P2.5  -  Unassigned,  Push-Pull,  Digital
    // P2.6  -  Unassigned,  Push-Pull,  Digital
    // P2.7  -  Unassigned,  Push-Pull,  Digital

    // P3.0  -  Skipped,     Open-Drain, Digital

    SFRPAGE   = CONFIG_PAGE;
    P0MDOUT   = 0xD3;
    P1MDOUT   = 0xFD;
    P2MDOUT   = 0xF1;
    P0SKIP    = 0xCF;
    P1SKIP    = 0x10;
    P3SKIP    = 0x01;
    XBR0      = 0x05;
    XBR1      = 0x0C;
    XBR2      = 0x42;
    SFRPAGE   = ACTIVE1_PAGE;
}

void Oscillator_Init()
{
    SFRPAGE   = CONFIG_PAGE;
    OSCICN    = 0xC7;
    SFRPAGE   = ACTIVE1_PAGE;
}

// Initialization function for device,
// Call Init_Device() from your main program
void Init_Device(void)
{
    //PCA0_Init();
    //Timer_Init();
    //UART_Init();
    //SPI_Init();
    //ADC_Init();
    //Voltage_Reference_Init();
    //Port_IO_Init();
    //Oscillator_Init();
}

*/

void SiLabs_Startup (void)
{
   PCA0MD &= ~0x40;                    // Disable the watchdog timer
}

void main (void)
{
  char a1 = 'a';
  char a2 = 'A';

   PORT_Init ();                       // Initialize Port I/O
   SYSCLK_Init ();                     // Initialize Oscillator
   UART0_Init ();

   while (1)
   {
       while (!SCON0_TI);
       SCON0_TI = 0;
       SBUF0 = a1;
       a1++;
       if(a1>'z') a1 = 'a';

       while (!SCON1_TI);
       SCON1_TI = 0;
       SBUF1 = a2;
       a2++;
       if(a2>'Z') a2 = 'A';
   }
}
