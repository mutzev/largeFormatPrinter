#include <SI_C8051F580_Register_Enums.h>                // SFR declarations

#define SYSCLK                      24000000    // Internal oscillator frequency in Hz
#define SPI_CLOCK                   2000000     // SPI clock
#define SerialPort_1_baudrate       115200
#define SerialPort_2_baudrate       115200

#define WDT_EN();                   PCA0MD |= 0x40      // enable the watchdog
#define WDT_DIS();                  PCA0MD &= ~0x40     // disable the watchdog
#define CLR_WDT();                  PCA0CPH2 = 0u;      // watchdog reset
#define ENABLE_ALL_INTERRUPTS       EA = 1u
#define DISABLE_ALL_INTERRUPTS      EA = 0u

void PCA0_Init (void);
void Timer_Init(void);
void UART_Init(void);
void SPI0_Init (void);
void ADC_Init(void);
void Voltage_Reference_Init(void);
void Port_Init (void);
void Oscillator_Init (void);
void Init_Device (void);
void SFR_Init (void);

void ClearExtWDT (void);
void writeToSerial_0 (uint8_t serial_0_Data);
void writeToSerial_1 (uint8_t serial_1_Data);

void SiLabs_Startup (void)
{
    WDT_DIS();      // Disable the watchdog
}

void main (void)
{
    Init_Device ();             // Initializes hardware peripherals

    while (1)
    {
       // CLR_WDT();                  // just kick the ugly dog (WDT period - X.XX sec.)
       // ClearExtWDT();

        writeToSerial_0 ('a');
    }
}

void PCA0_Init(void)
{
    PCA0CN    = 0x40;
    PCA0MD   &= ~0x40;
    PCA0MD    = 0x00;
}

void Timer_Init(void)
{
    TCON      = 0x40;
    TMOD      = 0x20;
    CKCON     = 0x08;
    TH1       = 0x98;
}

void UART_Init(void)
{
    SCON0     = 0x10;
    SFRPAGE   = CONFIG_PAGE;
    SBRLL0    = 0x98;
    SBRLH0    = 0xFF;
    SBCON0    = 0x43;
    SFRPAGE   = ACTIVE2_PAGE;
    SCON1     = 0x10;       // demoo source
    SFRPAGE = ACTIVE1_PAGE;             // Change for PCA0MD and SBUF0
}

void SPI0_Init(void)
{
    SPI0CFG   = 0x40;
    SPI0CN    = 0x0D;
    SPI0CKR   = 0x05;
}

void ADC_Init(void)
{
    ADC0MX    = 0x10;
    ADC0CF    = 0xFE;
}

void Voltage_Reference_Init(void)
{
    REF0CN    = 0x25;
}

void Oscillator_Init (void)
{
    SFRPAGE   = CONFIG_PAGE;
    OSCICN    = 0xC7;
    SFRPAGE = ACTIVE1_PAGE;             // Change for PCA0MD and SBUF0
}

void Port_Init (void)
{
    SFRPAGE   = CONFIG_PAGE;
    P0MDOUT   = 0xD3;
    P1MDOUT   = 0x7D;
    P2MDOUT   = 0xFC;
    P0SKIP    = 0xCF;
    P1SKIP    = 0x30;
    P3SKIP    = 0x01;
    XBR0      = 0x05;
    XBR2      = 0x42;
    SFRPAGE = ACTIVE1_PAGE;             // Change for PCA0MD and SBUF0

    P0 = 0xFC;              // set port 0 output state
    P1 = 0xFA;              // set port 1 output state
    P2 = 0x03;              // set port 2 output state
}

void Init_Device (void)
{
    PCA0_Init();
    Timer_Init();
    UART_Init();
    SPI0_Init();
    ADC_Init();
    Voltage_Reference_Init();
    Port_Init();
    Oscillator_Init();
}

void writeToSerial_0 (uint8_t serial_0_Data)
{
    SFRPAGE = 0x00;
    SBUF0 = serial_0_Data;
    SFRPAGE = ACTIVE1_PAGE;             // Change for PCA0MD and SBUF0
}

void writeToSerial_1 (uint8_t serial_1_Data)
{
    SFRPAGE = 0x10;
    SBUF1 = serial_1_Data;
    SFRPAGE = ACTIVE1_PAGE;             // Change for PCA0MD and SBUF0
}

